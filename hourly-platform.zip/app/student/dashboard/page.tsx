"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Bell, Search, Mail, Menu, User, X } from "lucide-react"
import { NotificationCenter } from "@/components/notification-center"
import { HourRequestModal } from "@/components/hour-request-modal"
import { useAppStore } from "@/lib/store"

export default function StudentDashboardPage() {
  const {
    currentUser,
    getTotalSignedUpHours,
    getTotalCompletedHours,
    getCompletedActivitiesCount,
    getNotificationsForStudent,
  } = useAppStore()
  const [showNotifications, setShowNotifications] = useState(false)
  const [showHourRequest, setShowHourRequest] = useState(false)
  const [showMenu, setShowMenu] = useState(false)

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to access the dashboard.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const totalSignedUpHours = getTotalSignedUpHours()
  const totalCompletedHours = getTotalCompletedHours()
  const completedActivitiesCount = getCompletedActivitiesCount()
  const notifications = getNotificationsForStudent(currentUser.id)
  const unreadNotifications = notifications.filter((n) => !n.read).length

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div>
              <h1 className="text-xl font-light">Dashboard</h1>
              <p className="text-sm text-gray-600">Welcome back, {currentUser.name}</p>
            </div>
            <div className="flex items-center space-x-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/student/opportunities">
                    <Button variant="ghost" size="icon" className="hover:bg-gray-100 rounded-full">
                      <Search className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Find Opportunities</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowHourRequest(true)}
                    className="hover:bg-gray-100 rounded-full"
                  >
                    <Mail className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Hour Requests</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowNotifications(true)}
                    className="hover:bg-gray-100 relative"
                  >
                    <Bell className="h-4 w-4" />
                    {unreadNotifications > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {unreadNotifications}
                      </span>
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Notifications</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/student/profile">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Link href="/student/committed-hours">
              <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Committed Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{totalSignedUpHours}</div>
                  <p className="text-xs text-gray-500 mt-1">Hours you've signed up for</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/student/completed-hours">
              <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Hours Completed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{totalCompletedHours}</div>
                  <p className="text-xs text-gray-500 mt-1">Approved by organizations</p>
                </CardContent>
              </Card>
            </Link>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Completed Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{completedActivitiesCount}</div>
                <p className="text-xs text-gray-500 mt-1">Individual opportunities</p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <Link href="/student/opportunities">
              <Button className="w-full bg-black hover:bg-gray-800 text-white">
                <Search className="h-4 w-4 mr-2" />
                Find Opportunities
              </Button>
            </Link>
            <Button
              onClick={() => setShowHourRequest(true)}
              variant="outline"
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
            >
              <Mail className="h-4 w-4 mr-2" />
              Request Hours
            </Button>
          </div>

          {/* Welcome Message */}
          <Card className="border-gray-200 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="text-4xl mb-4">🌟</div>
              <h3 className="text-lg font-semibold mb-2">Ready to make a difference?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Find volunteer opportunities that match your interests and schedule. Every hour counts towards building
                a better community.
              </p>
              <Link href="/student/opportunities">
                <Button className="bg-black hover:bg-gray-800 text-white">
                  <Search className="h-4 w-4 mr-2" />
                  Browse Opportunities
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Notification Center */}
        <NotificationCenter isOpen={showNotifications} onClose={() => setShowNotifications(false)} />

        {/* Hour Request Modal */}
        <HourRequestModal isOpen={showHourRequest} onClose={() => setShowHourRequest(false)} />
      </div>
    </TooltipProvider>
  )
}
