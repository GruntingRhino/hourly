"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Mail, Menu, User, X, Eye, RotateCcw, Search } from "lucide-react"
import { SwipeableOpportunityCard } from "@/components/swipeable-opportunity-card"
import { OpportunityDetailModal } from "@/components/opportunity-detail-modal"
import { HourRequestModal } from "@/components/hour-request-modal"
import { useAppStore } from "@/lib/store"

export default function ReviewedOpportunitiesPage() {
  const { currentUser, getReviewedOpportunities, markAsReviewed } = useAppStore()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedOpportunity, setSelectedOpportunity] = useState<any>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [showHourRequest, setShowHourRequest] = useState(false)

  // Only show skipped and rejected opportunities (not accepted ones)
  const reviewedOpportunities = getReviewedOpportunities().filter(
    (opp) => opp.reviewAction === "skipped" || opp.reviewAction === "rejected",
  )

  const handleSwipe = (direction: "left" | "right" | "down") => {
    if (currentIndex >= reviewedOpportunities.length) return

    const currentOpportunity = reviewedOpportunities[currentIndex]

    if (direction === "right") {
      // Re-accept the opportunity
      markAsReviewed(currentOpportunity.id, "accepted")
    } else if (direction === "left") {
      // Confirm rejection (keep as rejected)
      markAsReviewed(currentOpportunity.id, "rejected")
    } else if (direction === "down") {
      // Skip again (keep as skipped)
      markAsReviewed(currentOpportunity.id, "skipped")
    }

    setCurrentIndex((prev) => prev + 1)
  }

  const handleViewDetails = () => {
    if (currentIndex < reviewedOpportunities.length) {
      setSelectedOpportunity(reviewedOpportunities[currentIndex])
      setShowDetailModal(true)
    }
  }

  const resetStack = () => {
    setCurrentIndex(0)
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your reviewed opportunities.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/student/opportunities">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to Opportunities</p>
                </TooltipContent>
              </Tooltip>
              <h1 className="text-xl font-light">Reviewed Opportunities</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Link href="/student/opportunities">
                <Button variant="ghost" size="icon" className="hover:bg-gray-100 rounded-full">
                  <Search className="h-4 w-4" />
                </Button>
              </Link>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowHourRequest(true)}
                    className="hover:bg-gray-100 rounded-full"
                  >
                    <Mail className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Hour Requests</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/student/profile">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {reviewedOpportunities.length === 0 ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">📋</div>
                <h3 className="text-lg font-semibold mb-2">No reviewed opportunities</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Opportunities you skip or mark as "not interested" will appear here. You can re-accept them later.
                </p>
                <Link href="/student/opportunities">
                  <Button className="bg-black hover:bg-gray-800 text-white">Find Opportunities</Button>
                </Link>
              </CardContent>
            </Card>
          ) : currentIndex >= reviewedOpportunities.length ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">✅</div>
                <h3 className="text-lg font-semibold mb-2">All reviewed!</h3>
                <p className="text-gray-600 text-sm mb-4">
                  You've gone through all your previously reviewed opportunities.
                </p>
                <div className="flex justify-center space-x-4">
                  <Button
                    onClick={resetStack}
                    variant="outline"
                    className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Review Again
                  </Button>
                  <Link href="/student/opportunities">
                    <Button className="bg-black hover:bg-gray-800 text-white">Find New Opportunities</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* View Details Button */}
              <div className="flex justify-center">
                <Button
                  onClick={handleViewDetails}
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  View Details
                </Button>
              </div>

              {/* Opportunity Card */}
              <div className="flex justify-center">
                <SwipeableOpportunityCard
                  opportunity={reviewedOpportunities[currentIndex]}
                  onSwipe={handleSwipe}
                  showSwipeHints={true}
                />
              </div>

              {/* Progress Indicator */}
              <div className="text-center text-sm text-gray-500">
                {currentIndex + 1} of {reviewedOpportunities.length} reviewed opportunities
              </div>

              {/* Swipe Instructions */}
              <div className="text-center text-xs text-gray-400 bg-gray-50 p-3 rounded-lg">
                <p className="font-medium mb-1">Review Actions:</p>
                <p>Swipe right to re-accept • Swipe down to skip again • Swipe left to confirm rejection</p>
              </div>
            </div>
          )}
        </div>

        {/* Opportunity Detail Modal */}
        <OpportunityDetailModal
          opportunity={selectedOpportunity}
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(false)}
        />

        {/* Hour Request Modal */}
        <HourRequestModal isOpen={showHourRequest} onClose={() => setShowHourRequest(false)} />
      </div>
    </TooltipProvider>
  )
}
