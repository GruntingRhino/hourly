"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Clock, XCircle } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function CancelledMessagesPage() {
  const { currentUser, getCancelledHourRequests } = useAppStore()

  const cancelledRequests = currentUser ? getCancelledHourRequests(currentUser.id) : []

  const getStatusBadge = (status: string) => {
    return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Cancelled</Badge>
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your messages.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center space-x-4 p-4">
          <Link href="/student/messages">
            <Button variant="ghost" size="sm" className="hover:bg-gray-100">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-light">Cancelled Hour Requests</h1>
        </div>
      </header>

      <div className="p-4">
        {cancelledRequests.length === 0 ? (
          <Card className="border-gray-200 shadow-lg">
            <CardContent className="p-8 text-center">
              <div className="text-4xl mb-4">✅</div>
              <h3 className="text-lg font-semibold mb-2">No cancelled requests</h3>
              <p className="text-gray-600 text-sm mb-4">You haven't cancelled any hour requests yet.</p>
              <Link href="/student/messages">
                <Button className="bg-black hover:bg-gray-800 text-white">Back to Messages</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {cancelledRequests.map((request) => (
              <Card key={request.id} className="border-gray-200 shadow-lg">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg font-medium">{request.opportunityTitle}</CardTitle>
                      <div className="text-gray-600 font-medium">Hour Request</div>
                    </div>
                    {getStatusBadge(request.status)}
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Clock className="h-4 w-4" />
                      <span>{request.hoursCompleted} hours completed</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>Completed: {new Date(request.dateCompleted).toLocaleDateString()}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>Requested: {new Date(request.requestDate).toLocaleDateString()}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-600">
                      <XCircle className="h-4 w-4" />
                      <span>Cancelled by you</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
