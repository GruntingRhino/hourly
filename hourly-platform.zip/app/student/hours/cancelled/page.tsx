"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Clock, MapPin, User, XCircle } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function CancelledHoursPage() {
  const { currentUser, getCancelledLoggedHours } = useAppStore()

  const cancelledHours = getCancelledLoggedHours()

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your hours.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center space-x-4 p-4">
          <Link href="/student/hours">
            <Button variant="ghost" size="sm" className="hover:bg-gray-100">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-light">Cancelled Events</h1>
        </div>
      </header>

      <div className="p-4">
        {cancelledHours.length === 0 ? (
          <Card className="border-gray-200 shadow-lg">
            <CardContent className="p-8 text-center">
              <div className="text-4xl mb-4">✅</div>
              <h3 className="text-lg font-semibold mb-2">No cancelled events</h3>
              <p className="text-gray-600 text-sm mb-4">You haven't cancelled any events yet.</p>
              <Link href="/student/hours">
                <Button className="bg-black hover:bg-gray-800 text-white">Back to My Hours</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {cancelledHours.map((hour) => (
              <Card key={hour.id} className="border-gray-200 shadow-lg">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg font-medium">{hour.title}</CardTitle>
                      <div className="text-gray-600 font-medium">{hour.organization}</div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Cancelled</Badge>
                      <Badge variant="outline" className="border-black text-black">
                        {hour.hours}h
                      </Badge>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{hour.location}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(hour.date).toLocaleDateString()}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-600">
                      <User className="h-4 w-4" />
                      <span>{hour.supervisor}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-600">
                      <Clock className="h-4 w-4" />
                      <span>
                        {hour.startTime && hour.endTime ? `${hour.startTime} - ${hour.endTime}` : `${hour.hours} hours`}
                      </span>
                    </div>
                  </div>

                  <div className="text-sm text-gray-700 line-clamp-2">{hour.description}</div>

                  <div className="flex items-center space-x-2 text-sm text-gray-500 bg-gray-50 p-2 rounded">
                    <XCircle className="h-4 w-4" />
                    <span>Cancelled on {new Date(hour.dateLogged).toLocaleDateString()}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
