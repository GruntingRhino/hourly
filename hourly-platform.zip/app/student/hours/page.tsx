"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Calendar, Clock, MapPin, User, AlertCircle, X, Eye } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function StudentHoursPage() {
  const {
    currentUser,
    getActiveLoggedHours,
    getTotalSignedUpHours,
    getTotalCompletedHours,
    getCompletedActivitiesCount,
    cancelLoggedHour,
    isEventInPast,
  } = useAppStore()
  const [selectedHour, setSelectedHour] = useState<any>(null)
  const [showCancelDialog, setShowCancelDialog] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  const loggedHours = getActiveLoggedHours()
  const totalSignedUpHours = getTotalSignedUpHours()
  const totalCompletedHours = getTotalCompletedHours()
  const completedActivitiesCount = getCompletedActivitiesCount()

  const handleCancel = async () => {
    if (!selectedHour) return

    setIsProcessing(true)
    // Simulate API call
    setTimeout(() => {
      cancelLoggedHour(selectedHour.id)
      setShowCancelDialog(false)
      setSelectedHour(null)
      setIsProcessing(false)
    }, 1000)
  }

  const openCancelDialog = (hour: any) => {
    setSelectedHour(hour)
    setShowCancelDialog(true)
  }

  const canCancel = (hour: any) => {
    return hour.status !== "completed" && !isEventInPast(hour)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>
      case "accepted":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Accepted</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your hours.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const upcomingEvents = loggedHours
    .filter((hour) => !isEventInPast(hour) && hour.status !== "cancelled")
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  const pastEvents = loggedHours
    .filter((hour) => isEventInPast(hour) && hour.status !== "cancelled")
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/student/dashboard">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to Dashboard</p>
                </TooltipContent>
              </Tooltip>
              <h1 className="text-xl font-light">My Hours</h1>
            </div>
            <Link href="/student/hours/cancelled">
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-2" />
                View Cancelled
              </Button>
            </Link>
          </div>
        </header>

        <div className="p-4">
          {/* Hours Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Committed Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{totalSignedUpHours}</div>
                <p className="text-xs text-gray-500 mt-1">Total hours signed up for</p>
              </CardContent>
            </Card>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Hours Completed</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{totalCompletedHours}</div>
                <p className="text-xs text-gray-500 mt-1">Approved by organizations</p>
              </CardContent>
            </Card>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Completed Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{completedActivitiesCount}</div>
                <p className="text-xs text-gray-500 mt-1">Individual opportunities</p>
              </CardContent>
            </Card>
          </div>

          {/* Activities List */}
          {loggedHours.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Activities Yet</h3>
                <p className="text-gray-600 mb-4">You haven't signed up for any community service opportunities yet.</p>
                <Link href="/student/opportunities">
                  <Button>Browse Opportunities</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Upcoming Events */}
              {upcomingEvents.length > 0 && (
                <div>
                  <h3 className="text-lg font-medium mb-4">Upcoming Events</h3>
                  <div className="space-y-4">
                    {upcomingEvents.map((hour) => (
                      <Card key={hour.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-lg font-semibold text-gray-900">{hour.title}</h3>
                                {getStatusBadge(hour.status)}
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                                <div className="flex items-center gap-2">
                                  <User className="h-4 w-4" />
                                  <span>{hour.organization}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Calendar className="h-4 w-4" />
                                  <span>{new Date(hour.date).toLocaleDateString()}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4" />
                                  <span>{hour.hours} hours</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <MapPin className="h-4 w-4" />
                                  <span>{hour.location}</span>
                                </div>
                              </div>
                            </div>

                            <div className="ml-4 flex flex-col gap-2">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <div>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => openCancelDialog(hour)}
                                      disabled={!canCancel(hour)}
                                      className={`${
                                        !canCancel(hour)
                                          ? "opacity-50 cursor-not-allowed"
                                          : "hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                                      }`}
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>
                                    {hour.status === "completed"
                                      ? "Cannot cancel completed activities"
                                      : isEventInPast(hour)
                                        ? "Cannot cancel past events"
                                        : "Cancel this opportunity"}
                                  </p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Past Events */}
              {pastEvents.length > 0 && (
                <div>
                  <h3 className="text-lg font-medium mb-4">Past Events</h3>
                  <div className="space-y-4">
                    {pastEvents.map((hour) => (
                      <Card key={hour.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-lg font-semibold text-gray-900">{hour.title}</h3>
                                {getStatusBadge(hour.status)}
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                                <div className="flex items-center gap-2">
                                  <User className="h-4 w-4" />
                                  <span>{hour.organization}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Calendar className="h-4 w-4" />
                                  <span>{new Date(hour.date).toLocaleDateString()}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4" />
                                  <span>{hour.hours} hours</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <MapPin className="h-4 w-4" />
                                  <span>{hour.location}</span>
                                </div>
                              </div>
                            </div>

                            <div className="ml-4 flex flex-col gap-2">
                              {hour.hasRequest && (
                                <Badge variant="secondary" className="text-xs">
                                  Hours Requested
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Cancel Dialog */}
          <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Cancel Activity</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Are you sure you want to cancel this activity? This action cannot be undone.
                  </AlertDescription>
                </Alert>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
                    Keep Activity
                  </Button>
                  <Button variant="destructive" onClick={handleCancel} disabled={isProcessing}>
                    {isProcessing ? "Cancelling..." : "Cancel Activity"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </TooltipProvider>
  )
}
