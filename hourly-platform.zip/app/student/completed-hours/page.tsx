"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Calendar, Clock, MapPin, User, Phone, Mail } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function CompletedHoursPage() {
  const { currentUser, getCompletedHours, getTotalCompletedHours, formatDate } = useAppStore()

  const completedHours = getCompletedHours()
  const totalCompletedHours = getTotalCompletedHours()

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your completed hours.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/student/dashboard">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to Dashboard</p>
                </TooltipContent>
              </Tooltip>
              <h1 className="text-xl font-light">Completed Hours</h1>
            </div>
          </div>
        </header>

        <div className="p-4">
          {/* Hours Summary */}
          <div className="mb-6">
            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Total Completed Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{totalCompletedHours}</div>
                <p className="text-xs text-gray-500 mt-1">Hours approved by organizations</p>
              </CardContent>
            </Card>
          </div>

          {/* Completed Activities List */}
          {completedHours.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Completed Hours Yet</h3>
                <p className="text-gray-600 mb-4">
                  Complete volunteer activities and request hour approval to see them here.
                </p>
                <Link href="/student/opportunities">
                  <Button>Browse Opportunities</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-medium mb-4">Your Completed Activities</h3>
              {completedHours
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map((hour) => (
                  <Card key={hour.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-900">{hour.title}</h3>
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>
                          </div>

                          <div className="text-gray-600 font-medium mb-2">{hour.organization}</div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600 mb-4">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDate(hour.date)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4" />
                              <span>{hour.hours} hours</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              <span>{hour.address}</span>
                            </div>
                            {hour.startTime && hour.endTime && (
                              <div className="flex items-center gap-2">
                                <Clock className="h-4 w-4" />
                                <span>
                                  {hour.startTime} - {hour.endTime}
                                </span>
                              </div>
                            )}
                          </div>

                          {/* Supervisor Contact Info */}
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <User className="h-4 w-4 text-gray-600" />
                              <span className="font-medium text-gray-900">{hour.supervisor}</span>
                            </div>
                            {hour.supervisorPhone && (
                              <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                                <Phone className="h-4 w-4" />
                                <span>{hour.supervisorPhone}</span>
                              </div>
                            )}
                            {hour.supervisorEmail && (
                              <div className="flex items-center gap-2 text-sm text-gray-600">
                                <Mail className="h-4 w-4" />
                                <span>{hour.supervisorEmail}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          )}
        </div>
      </div>
    </TooltipProvider>
  )
}
