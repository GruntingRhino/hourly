export default function Loading() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center space-x-4 p-4">
          <div className="w-8 h-8 bg-gray-200 rounded animate-pulse"></div>
          <div className="w-32 h-6 bg-gray-200 rounded animate-pulse"></div>
        </div>
      </header>

      <div className="p-4">
        <div className="space-y-6">
          {[1, 2].map((i) => (
            <div key={i} className="border border-gray-200 rounded-lg p-6">
              <div className="w-24 h-6 bg-gray-200 rounded animate-pulse mb-4"></div>
              <div className="space-y-4">
                {[1, 2].map((j) => (
                  <div key={j} className="p-4 bg-gray-50 rounded-lg">
                    <div className="w-48 h-5 bg-gray-200 rounded animate-pulse mb-2"></div>
                    <div className="w-32 h-4 bg-gray-200 rounded animate-pulse mb-3"></div>
                    <div className="grid grid-cols-2 gap-3">
                      {[1, 2, 3, 4].map((k) => (
                        <div key={k} className="w-24 h-4 bg-gray-200 rounded animate-pulse"></div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
