"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Clock, MapPin, User, AlertTriangle } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function OverlappingEventsPage() {
  const { getActiveLoggedHours, hasTimeConflict, currentUser } = useAppStore()
  const [selectedEvent, setSelectedEvent] = useState<any>(null)

  const loggedHours = getActiveLoggedHours()
  const overlappingGroups: any[] = []

  // Find all overlapping events
  loggedHours.forEach((hour, index) => {
    const conflicts = hasTimeConflict(hour, loggedHours.slice(index + 1))
    if (conflicts.length > 0) {
      const existingGroup = overlappingGroups.find((group) => group.some((event: any) => event.id === hour.id))

      if (!existingGroup) {
        overlappingGroups.push([hour, ...conflicts])
      }
    }
  })

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your events.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center space-x-4 p-4">
          <Link href="/student/hours">
            <Button variant="ghost" size="sm" className="hover:bg-gray-100">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-light">Overlapping Events</h1>
        </div>
      </header>

      <div className="p-4">
        {overlappingGroups.length === 0 ? (
          <Card className="border-gray-200 shadow-lg">
            <CardContent className="p-8 text-center">
              <div className="text-4xl mb-4">✅</div>
              <h3 className="text-lg font-semibold mb-2">No Conflicts Found</h3>
              <p className="text-gray-600 text-sm mb-4">Great! None of your scheduled events have time conflicts.</p>
              <Link href="/student/hours">
                <Button className="bg-black hover:bg-gray-800 text-white">Back to My Hours</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center space-x-2 text-yellow-600">
              <AlertTriangle className="h-5 w-5" />
              <span className="font-medium">
                {overlappingGroups.length} conflict{overlappingGroups.length > 1 ? "s" : ""} found
              </span>
            </div>

            {overlappingGroups.map((group, groupIndex) => (
              <Card key={groupIndex} className="border-yellow-200 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg font-medium text-yellow-800">Conflict #{groupIndex + 1}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {group.map((event: any, eventIndex: number) => (
                    <div key={event.id} className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-medium text-yellow-800">{event.title}</h4>
                          <div className="text-yellow-700 font-medium">{event.organization}</div>
                        </div>
                        <Badge variant="outline" className="border-yellow-600 text-yellow-800">
                          {event.hours}h
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                        <div className="flex items-center space-x-2 text-yellow-700">
                          <MapPin className="h-4 w-4" />
                          <span>{event.location}</span>
                        </div>

                        <div className="flex items-center space-x-2 text-yellow-700">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(event.date).toLocaleDateString()}</span>
                        </div>

                        <div className="flex items-center space-x-2 text-yellow-700">
                          <User className="h-4 w-4" />
                          <span>{event.supervisor}</span>
                        </div>

                        <div className="flex items-center space-x-2 text-yellow-700">
                          <Clock className="h-4 w-4" />
                          <span>
                            {event.startTime && event.endTime
                              ? `${event.startTime} - ${event.endTime}`
                              : `${event.hours} hours`}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}

                  <div className="text-sm text-yellow-700 bg-yellow-100 p-3 rounded-lg">
                    <strong>Resolution needed:</strong> These events have overlapping times. You may need to cancel one
                    of them or contact the organizations to resolve the conflict.
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
