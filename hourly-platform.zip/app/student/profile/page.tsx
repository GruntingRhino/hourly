"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, AlertCircle, Trash2, Mail, Menu, X, Search } from "lucide-react"
import { DeleteAccountModal } from "@/components/delete-account-modal"
import { useAppStore } from "@/lib/store"
import { HourRequestModal } from "@/components/hour-request-modal"

export default function StudentProfilePage() {
  const { currentUser, deleteUser, setCurrentUser } = useAppStore()
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [showHourRequest, setShowHourRequest] = useState(false)

  const handleDeleteAccount = () => {
    if (currentUser) {
      deleteUser(currentUser.id)
      setCurrentUser(null)
    }
  }

  if (!currentUser || currentUser.type !== "student") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only students can access this page.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4">
            <Link href="/student/dashboard">
              <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-xl font-light">Profile</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Link href="/student/opportunities">
              <Button variant="ghost" size="icon" className="hover:bg-gray-100 rounded-full">
                <Search className="h-4 w-4" />
              </Button>
            </Link>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowHourRequest(true)}
              className="hover:bg-gray-100 rounded-full"
            >
              <Mail className="h-4 w-4" />
            </Button>

            <Button variant="ghost" size="sm" onClick={() => setShowMenu(!showMenu)} className="hover:bg-gray-100">
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {showMenu && (
          <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
            <Link href="/login">
              <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                <X className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </Link>
          </div>
        )}
      </header>

      <div className="p-4">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Profile Information */}
          <Card className="border-gray-200 shadow-lg">
            <CardHeader>
              <CardTitle className="font-medium">Profile Information</CardTitle>
              <CardDescription>Your account details (cannot be changed)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" value={currentUser.name} className="border-gray-300 bg-gray-50" disabled />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    value={currentUser.age?.toString() || ""}
                    className="border-gray-300 bg-gray-50"
                    disabled
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={currentUser.email}
                    className="border-gray-300 bg-gray-50"
                    disabled
                  />
                </div>

                <Alert className="border-blue-200 bg-blue-50">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    Profile information cannot be edited after account creation for security purposes.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>

          {/* Danger Zone */}
          <Card className="border-red-200 shadow-lg">
            <CardHeader>
              <CardTitle className="font-medium text-red-700">Danger Zone</CardTitle>
              <CardDescription>Irreversible and destructive actions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50">
                <div>
                  <h4 className="font-medium text-red-800">Delete Account</h4>
                  <p className="text-sm text-red-600">
                    Permanently delete your account and all associated data. This action cannot be undone.
                  </p>
                </div>
                <Button
                  variant="destructive"
                  onClick={() => setShowDeleteModal(true)}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Delete Account Modal */}
      <DeleteAccountModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleDeleteAccount}
        userType="student"
      />

      {/* Hour Request Modal */}
      <HourRequestModal isOpen={showHourRequest} onClose={() => setShowHourRequest(false)} />
    </div>
  )
}
