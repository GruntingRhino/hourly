"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Calendar, Clock, MapPin, User, CheckCircle } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function CompletedHoursPage() {
  const { currentUser, getCompletedHours, formatDate } = useAppStore()

  if (!currentUser || currentUser.type !== "user") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your completed hours.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const completedHours = getCompletedHours()
  const totalHours = completedHours.reduce((sum, hour) => sum + hour.hours, 0)

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center space-x-4 p-4">
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/user/dashboard">
                  <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>Back to Dashboard</p>
              </TooltipContent>
            </Tooltip>
            <div>
              <h1 className="text-xl font-light">Completed Hours</h1>
              <p className="text-sm text-gray-600">Your verified volunteer hours</p>
            </div>
          </div>
        </header>

        <div className="p-4">
          {/* Summary Card */}
          <Card className="border-gray-200 shadow-lg mb-6">
            <CardHeader>
              <CardTitle className="text-lg font-medium">Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">{totalHours}</div>
                  <p className="text-sm text-gray-600">Total Hours Completed</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">{completedHours.length}</div>
                  <p className="text-sm text-gray-600">Activities Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {completedHours.length === 0 ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">🏆</div>
                <h3 className="text-lg font-semibold mb-2">No completed hours yet</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Complete volunteer activities and get them approved to see them here.
                </p>
                <Link href="/user/opportunities">
                  <Button className="bg-black hover:bg-gray-800 text-white">Find Opportunities</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              <h2 className="text-lg font-medium">Completed Activities</h2>
              {completedHours.map((hour) => (
                <Card key={hour.id} className="border-gray-200 shadow-lg">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg font-medium">{hour.title}</CardTitle>
                        <div className="text-gray-600 font-medium">{hour.organization}</div>
                        {hour.supervisor && (
                          <div className="text-sm text-gray-500 mt-1">Supervisor: {hour.supervisor}</div>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="border-black text-black">
                          {hour.hours}h
                        </Badge>
                        <Badge className="bg-green-100 text-green-800 border-green-200">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Completed
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <MapPin className="h-4 w-4" />
                        <span>{hour.address}</span>
                      </div>

                      <div className="flex items-center space-x-2 text-gray-600">
                        <Calendar className="h-4 w-4" />
                        <span>{formatDate(hour.date)}</span>
                      </div>

                      <div className="flex items-center space-x-2 text-gray-600">
                        <User className="h-4 w-4" />
                        <span>{hour.supervisor}</span>
                      </div>

                      {hour.startTime && hour.endTime && (
                        <div className="flex items-center space-x-2 text-gray-600">
                          <Clock className="h-4 w-4" />
                          <span>
                            {hour.startTime} - {hour.endTime}
                          </span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </TooltipProvider>
  )
}
