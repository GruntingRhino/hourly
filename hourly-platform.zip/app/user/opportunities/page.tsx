"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Mail, Menu, User, X, Eye, RotateCcw } from "lucide-react"
import { SwipeableOpportunityCard } from "@/components/swipeable-opportunity-card"
import { OpportunityDetailModal } from "@/components/opportunity-detail-modal"
import { HourRequestModal } from "@/components/hour-request-modal"
import { useAppStore } from "@/lib/store"

export default function UserOpportunitiesPage() {
  const { currentUser, getAvailableOpportunities, markAsReviewed } = useAppStore()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedOpportunity, setSelectedOpportunity] = useState<any>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [showHourRequest, setShowHourRequest] = useState(false)

  const opportunities = getAvailableOpportunities(currentUser?.id)

  const handleSwipe = (direction: "left" | "right" | "down") => {
    if (currentIndex >= opportunities.length) return

    const currentOpportunity = opportunities[currentIndex]

    if (direction === "right") {
      markAsReviewed(currentOpportunity.id, "accepted")
    } else if (direction === "left") {
      markAsReviewed(currentOpportunity.id, "rejected")
    } else if (direction === "down") {
      markAsReviewed(currentOpportunity.id, "skipped")
    }

    setCurrentIndex((prev) => prev + 1)
  }

  const handleViewDetails = () => {
    if (currentIndex < opportunities.length) {
      setSelectedOpportunity(opportunities[currentIndex])
      setShowDetailModal(true)
    }
  }

  const resetStack = () => {
    setCurrentIndex(0)
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view opportunities.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/user/dashboard">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to Dashboard</p>
                </TooltipContent>
              </Tooltip>
              <h1 className="text-xl font-light">Find Opportunities</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowHourRequest(true)}
                    className="hover:bg-gray-100 rounded-full"
                  >
                    <Mail className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Hour Requests</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/user/reviewed-opportunities">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Reviewed Opportunities</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/user/profile">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {opportunities.length === 0 ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">🎯</div>
                <h3 className="text-lg font-semibold mb-2">No opportunities available</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Check back later for new volunteer opportunities, or review your previously skipped opportunities.
                </p>
                <div className="flex justify-center space-x-4">
                  <Link href="/user/reviewed-opportunities">
                    <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Review Skipped
                    </Button>
                  </Link>
                  <Link href="/user/dashboard">
                    <Button className="bg-black hover:bg-gray-800 text-white">Back to Dashboard</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ) : currentIndex >= opportunities.length ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">✅</div>
                <h3 className="text-lg font-semibold mb-2">All caught up!</h3>
                <p className="text-gray-600 text-sm mb-4">
                  You've reviewed all available opportunities. Check back later for new ones.
                </p>
                <div className="flex justify-center space-x-4">
                  <Button
                    onClick={resetStack}
                    variant="outline"
                    className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Review Again
                  </Button>
                  <Link href="/user/dashboard">
                    <Button className="bg-black hover:bg-gray-800 text-white">Back to Dashboard</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* View Details Button */}
              <div className="flex justify-center">
                <Button
                  onClick={handleViewDetails}
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  View Details
                </Button>
              </div>

              {/* Opportunity Card */}
              <div className="flex justify-center">
                <SwipeableOpportunityCard opportunity={opportunities[currentIndex]} onSwipe={handleSwipe} />
              </div>

              {/* Progress Indicator */}
              <div className="text-center text-sm text-gray-500">
                {currentIndex + 1} of {opportunities.length} opportunities
              </div>
            </div>
          )}
        </div>

        {/* Opportunity Detail Modal */}
        <OpportunityDetailModal
          opportunity={selectedOpportunity}
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(false)}
        />

        {/* Hour Request Modal */}
        <HourRequestModal isOpen={showHourRequest} onClose={() => setShowHourRequest(false)} />
      </div>
    </TooltipProvider>
  )
}
