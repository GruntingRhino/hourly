"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, RotateCcw } from "lucide-react"
import { OpportunityCard } from "@/components/opportunity-card"
import { OpportunityDetailModal } from "@/components/opportunity-detail-modal"
import { useAppStore } from "@/lib/store"

export default function ReviewedOpportunitiesPage() {
  const { currentUser, getReviewedOpportunities, markAsReviewed } = useAppStore()
  const [selectedOpportunity, setSelectedOpportunity] = useState<any>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)

  if (!currentUser || currentUser.type !== "user") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view reviewed opportunities.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const reviewedOpportunities = getReviewedOpportunities()
  const skippedOrRejected = reviewedOpportunities.filter(
    (opp: any) => opp.reviewAction === "skipped" || opp.reviewAction === "rejected",
  )

  const handleViewDetails = (opportunity: any) => {
    setSelectedOpportunity(opportunity)
    setShowDetailModal(true)
  }

  const handleSignUp = (opportunity: any) => {
    markAsReviewed(opportunity.id, "accepted")
  }

  const handleSkip = (opportunity: any) => {
    markAsReviewed(opportunity.id, "skipped")
  }

  const handleReject = (opportunity: any) => {
    markAsReviewed(opportunity.id, "rejected")
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center space-x-4 p-4">
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/user/opportunities">
                  <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>Back to Opportunities</p>
              </TooltipContent>
            </Tooltip>
            <div>
              <h1 className="text-xl font-light">Reviewed Opportunities</h1>
              <p className="text-sm text-gray-600">Previously skipped or rejected opportunities</p>
            </div>
          </div>
        </header>

        <div className="p-4">
          {skippedOrRejected.length === 0 ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">📋</div>
                <h3 className="text-lg font-semibold mb-2">No reviewed opportunities</h3>
                <p className="text-gray-600 text-sm mb-4">You haven't skipped or rejected any opportunities yet.</p>
                <Link href="/user/opportunities">
                  <Button className="bg-black hover:bg-gray-800 text-white">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Find Opportunities
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              <div className="text-sm text-gray-600 mb-4">
                Showing {skippedOrRejected.length} previously reviewed opportunities
              </div>

              {skippedOrRejected.map((opportunity: any) => (
                <OpportunityCard
                  key={opportunity.id}
                  opportunity={opportunity}
                  onViewDetails={() => handleViewDetails(opportunity)}
                  onSignUp={() => handleSignUp(opportunity)}
                  onSkip={() => handleSkip(opportunity)}
                  onReject={() => handleReject(opportunity)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Opportunity Detail Modal */}
        <OpportunityDetailModal
          opportunity={selectedOpportunity}
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(false)}
        />
      </div>
    </TooltipProvider>
  )
}
