"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Calendar, Clock, MapPin, User, Phone, Mail, Menu, X, Search } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function CommittedHoursPage() {
  const { currentUser, getActiveLoggedHours, cancelLoggedHour, isEventInPast, formatDate } = useAppStore()
  const [showMenu, setShowMenu] = useState(false)

  if (!currentUser || currentUser.type !== "user") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only users can access this page.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const activeHours = getActiveLoggedHours()

  // Separate upcoming and past activities
  const upcomingActivities = activeHours.filter((hour) => !isEventInPast(hour))
  const pastActivities = activeHours.filter((hour) => isEventInPast(hour))

  const handleCancel = (hourId: string) => {
    if (confirm("Are you sure you want to cancel this activity? This action cannot be undone.")) {
      cancelLoggedHour(hourId)
    }
  }

  const ActivityCard = ({ activity, isPast = false }: { activity: any; isPast?: boolean }) => (
    <Card key={activity.id} className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-medium">{activity.title}</CardTitle>
            <div className="text-gray-600 font-medium">{activity.organization}</div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="border-black text-black">
              {activity.hours}h
            </Badge>
            <Badge
              variant={activity.status === "completed" ? "default" : "secondary"}
              className={
                activity.status === "completed"
                  ? "bg-green-100 text-green-800 border-green-200"
                  : "bg-blue-100 text-blue-800 border-blue-200"
              }
            >
              {activity.status === "completed" ? "Completed" : "Signed Up"}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin className="h-4 w-4" />
            <span>{activity.location}</span>
          </div>

          <div className="flex items-center space-x-2 text-gray-600">
            <Calendar className="h-4 w-4" />
            <span>{formatDate(activity.date)}</span>
          </div>

          <div className="flex items-center space-x-2 text-gray-600">
            <User className="h-4 w-4" />
            <span>{activity.supervisor}</span>
          </div>

          {activity.startTime && activity.endTime && (
            <div className="flex items-center space-x-2 text-gray-600">
              <Clock className="h-4 w-4" />
              <span>
                {activity.startTime} - {activity.endTime}
              </span>
            </div>
          )}
        </div>

        {/* Supervisor Contact Information */}
        <div className="border-t pt-3">
          <h4 className="font-medium text-sm mb-2">Contact Information</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
            <div className="flex items-center space-x-2 text-gray-600">
              <Mail className="h-4 w-4" />
              <span className="truncate">supervisor@example.com</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <Phone className="h-4 w-4" />
              <span>(555) 123-4567</span>
            </div>
          </div>
        </div>

        {!isPast && (
          <div className="flex justify-end pt-2 border-t">
            <Button
              onClick={() => handleCancel(activity.id)}
              variant="outline"
              size="sm"
              className="border-red-300 text-red-700 hover:bg-red-50 bg-transparent"
            >
              Cancel
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/user/dashboard">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to Dashboard</p>
                </TooltipContent>
              </Tooltip>
              <div>
                <h1 className="text-xl font-light">My Activities</h1>
                <p className="text-sm text-gray-600">All your signed-up volunteer activities</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/user/opportunities">
                    <Button variant="ghost" size="icon" className="hover:bg-gray-100 rounded-full">
                      <Search className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Find Opportunities</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/user/profile">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {activeHours.length === 0 ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">📅</div>
                <h3 className="text-lg font-semibold mb-2">No activities yet</h3>
                <p className="text-gray-600 text-sm mb-4">You haven't signed up for any volunteer opportunities yet.</p>
                <Link href="/user/opportunities">
                  <Button className="bg-black hover:bg-gray-800 text-white">
                    <Search className="h-4 w-4 mr-2" />
                    Find Opportunities
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-8">
              {/* Upcoming Activities */}
              {upcomingActivities.length > 0 && (
                <div>
                  <h2 className="text-lg font-medium mb-4">Upcoming Activities ({upcomingActivities.length})</h2>
                  <div className="space-y-4">
                    {upcomingActivities.map((activity) => (
                      <ActivityCard key={activity.id} activity={activity} />
                    ))}
                  </div>
                </div>
              )}

              {/* Past Activities */}
              {pastActivities.length > 0 && (
                <div>
                  <h2 className="text-lg font-medium mb-4">Past Activities ({pastActivities.length})</h2>
                  <div className="space-y-4">
                    {pastActivities.map((activity) => (
                      <ActivityCard key={activity.id} activity={activity} isPast={true} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </TooltipProvider>
  )
}
