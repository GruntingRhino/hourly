"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, User, Search, Menu, X, Bell } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { NotificationCenter } from "@/components/notification-center"

export default function UserDashboardPage() {
  const {
    currentUser,
    getActiveLoggedHours,
    getTotalSignedUpHours,
    getTotalCompletedHours,
    getCompletedActivitiesCount,
    getNotificationsForStudent,
    formatDate,
  } = useAppStore()
  const [showMenu, setShowMenu] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)

  if (!currentUser || currentUser.type !== "user") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only users can access this dashboard.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const activeHours = getActiveLoggedHours()
  const totalSignedUpHours = getTotalSignedUpHours()
  const totalCompletedHours = getTotalCompletedHours()
  const completedActivitiesCount = getCompletedActivitiesCount()
  const notifications = getNotificationsForStudent(currentUser.id)
  const unreadNotifications = notifications.filter((n) => !n.read).length

  // Separate upcoming and past activities
  const upcomingActivities = activeHours.filter((hour) => {
    const eventDate = new Date(hour.date + "T" + (hour.startTime || "00:00:00"))
    return eventDate >= new Date()
  })

  const pastActivities = activeHours.filter((hour) => {
    const eventDate = new Date(hour.date + "T" + (hour.startTime || "23:59:59"))
    return eventDate < new Date()
  })

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div>
              <h1 className="text-xl font-light">Dashboard</h1>
              <p className="text-sm text-gray-600">Welcome back, {currentUser.name}</p>
            </div>
            <div className="flex items-center space-x-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowNotifications(true)}
                    className="hover:bg-gray-100 rounded-full relative"
                  >
                    <Bell className="h-4 w-4" />
                    {unreadNotifications > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {unreadNotifications}
                      </span>
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Notifications</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/user/opportunities">
                    <Button variant="ghost" size="icon" className="hover:bg-gray-100 rounded-full">
                      <Search className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Find Opportunities</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/user/profile">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Link href="/user/committed-hours">
              <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Signed Up Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{totalSignedUpHours}</div>
                  <p className="text-xs text-gray-500 mt-1">Total committed</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/user/completed-hours">
              <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Hours Completed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{totalCompletedHours}</div>
                  <p className="text-xs text-gray-500 mt-1">Verified hours</p>
                </CardContent>
              </Card>
            </Link>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Activities Done</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{completedActivitiesCount}</div>
                <p className="text-xs text-gray-500 mt-1">Completed events</p>
              </CardContent>
            </Card>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Upcoming Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">{upcomingActivities.length}</div>
                <p className="text-xs text-gray-500 mt-1">Events scheduled</p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Link href="/user/opportunities" className="flex-1">
              <Button className="w-full bg-black hover:bg-gray-800 text-white">
                <Search className="h-4 w-4 mr-2" />
                Find Opportunities
              </Button>
            </Link>
            <Link href="/user/committed-hours">
              <Button
                variant="outline"
                className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
              >
                <Calendar className="h-4 w-4 mr-2" />
                My Activities
              </Button>
            </Link>
          </div>

          {/* Upcoming Activities */}
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-medium">Upcoming Activities</h2>
                <Link href="/user/committed-hours">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                  >
                    View All
                  </Button>
                </Link>
              </div>

              {upcomingActivities.length === 0 ? (
                <Card className="border-gray-200 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="text-4xl mb-4">📅</div>
                    <h3 className="text-lg font-semibold mb-2">No upcoming activities</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      You haven't signed up for any volunteer opportunities yet.
                    </p>
                    <Link href="/user/opportunities">
                      <Button className="bg-black hover:bg-gray-800 text-white">
                        <Search className="h-4 w-4 mr-2" />
                        Find Opportunities
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {upcomingActivities.slice(0, 3).map((activity) => (
                    <Card key={activity.id} className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg font-medium">{activity.title}</CardTitle>
                            <div className="text-gray-600 font-medium">{activity.organization}</div>
                          </div>
                          <Badge variant="outline" className="border-black text-black">
                            {activity.hours}h
                          </Badge>
                        </div>
                      </CardHeader>

                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                          <div className="flex items-center space-x-2 text-gray-600">
                            <MapPin className="h-4 w-4" />
                            <span>{activity.location}</span>
                          </div>

                          <div className="flex items-center space-x-2 text-gray-600">
                            <Calendar className="h-4 w-4" />
                            <span>{formatDate(activity.date)}</span>
                          </div>

                          <div className="flex items-center space-x-2 text-gray-600">
                            <User className="h-4 w-4" />
                            <span>{activity.supervisor}</span>
                          </div>

                          {activity.startTime && activity.endTime && (
                            <div className="flex items-center space-x-2 text-gray-600">
                              <Clock className="h-4 w-4" />
                              <span>
                                {activity.startTime} - {activity.endTime}
                              </span>
                            </div>
                          )}
                        </div>

                        <div className="flex justify-between items-center pt-2">
                          <Badge
                            variant={activity.status === "completed" ? "default" : "secondary"}
                            className={
                              activity.status === "completed"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : "bg-blue-100 text-blue-800 border-blue-200"
                            }
                          >
                            {activity.status === "completed" ? "Completed" : "Signed Up"}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Notification Center */}
        <NotificationCenter isOpen={showNotifications} onClose={() => setShowNotifications(false)} />
      </div>
    </TooltipProvider>
  )
}
