"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, User, Mail, Calendar, Clock } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function UserProfilePage() {
  const { currentUser, getTotalCompletedHours, getCompletedActivitiesCount } = useAppStore()

  if (!currentUser || currentUser.type !== "user") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Please Sign In</h3>
            <p className="text-gray-600 text-sm mb-4">You need to be logged in to view your profile.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const totalCompletedHours = getTotalCompletedHours()
  const completedActivitiesCount = getCompletedActivitiesCount()

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center space-x-4 p-4">
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/user/dashboard">
                  <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>Back to Dashboard</p>
              </TooltipContent>
            </Tooltip>
            <div>
              <h1 className="text-xl font-light">Profile</h1>
              <p className="text-sm text-gray-600">Your account information</p>
            </div>
          </div>
        </header>

        <div className="p-4 max-w-2xl mx-auto">
          {/* Profile Information */}
          <Card className="border-gray-200 shadow-lg mb-6">
            <CardHeader>
              <CardTitle className="text-lg font-medium flex items-center">
                <User className="h-5 w-5 mr-2" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Full Name</label>
                  <p className="text-lg">{currentUser.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Email</label>
                  <p className="text-lg flex items-center">
                    <Mail className="h-4 w-4 mr-2" />
                    {currentUser.email}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Age</label>
                  <p className="text-lg">{currentUser.age} years old</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Account Type</label>
                  <Badge variant="outline" className="border-black text-black">
                    Volunteer
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Volunteer Statistics */}
          <Card className="border-gray-200 shadow-lg mb-6">
            <CardHeader>
              <CardTitle className="text-lg font-medium flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Volunteer Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">{totalCompletedHours}</div>
                  <p className="text-sm text-gray-600">Total Hours Completed</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">{completedActivitiesCount}</div>
                  <p className="text-sm text-gray-600">Activities Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Actions */}
          <Card className="border-gray-200 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg font-medium">Account Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-yellow-600 mr-2" />
                  <div>
                    <h4 className="font-medium text-yellow-800">Profile Information</h4>
                    <p className="text-sm text-yellow-700">
                      Your profile information cannot be changed after account creation.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <Link href="/user/dashboard">
                  <Button className="bg-black hover:bg-gray-800 text-white">Back to Dashboard</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </TooltipProvider>
  )
}
