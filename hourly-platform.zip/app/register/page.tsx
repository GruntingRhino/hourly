"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function RegisterPage() {
  const { addUser, setCurrentUser } = useAppStore()
  const [userType, setUserType] = useState<"user" | "nonprofit" | "">("")
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    age: "",
    organizationName: "",
    phone: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showDisclaimer, setShowDisclaimer] = useState(false)

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = "Name is required"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address"
    }

    if (!userType) {
      newErrors.userType = "Please select an account type"
    }

    if (userType === "user") {
      if (!formData.age) {
        newErrors.age = "Age is required"
      } else {
        const age = Number.parseInt(formData.age)
        if (isNaN(age) || age < 13 || age > 25) {
          newErrors.age = "Age must be between 13 and 25"
        }
      }
    }

    if (userType === "nonprofit") {
      if (!formData.organizationName.trim()) {
        newErrors.organizationName = "Organization name is required"
      }
      if (!formData.phone.trim()) {
        newErrors.phone = "Phone number is required"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setShowDisclaimer(true)
  }

  const confirmRegistration = async () => {
    setIsSubmitting(true)

    try {
      const userData = {
        name: formData.name.trim(),
        email: formData.email.trim().toLowerCase(),
        type: userType as "user" | "nonprofit",
        ...(userType === "user" && {
          age: Number.parseInt(formData.age),
        }),
        ...(userType === "nonprofit" && {
          organizationName: formData.organizationName.trim(),
          phone: formData.phone.trim(),
        }),
      }

      const success = addUser(userData)

      if (success) {
        // Auto-login the user
        const newUser = {
          ...userData,
          id: "temp", // Will be set by the store
          createdAt: new Date().toISOString(),
        }
        setCurrentUser(newUser)

        // Redirect based on user type
        if (userType === "user") {
          window.location.href = "/user/dashboard"
        } else {
          window.location.href = "/nonprofit/dashboard"
        }
      } else {
        setErrors({ email: "An account with this email already exists" })
        setShowDisclaimer(false)
      }
    } catch (error) {
      console.error("Registration failed:", error)
      setErrors({ general: "Registration failed. Please try again." })
      setShowDisclaimer(false)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-light">Create Account</CardTitle>
          <p className="text-sm text-gray-600">Join our volunteer community</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {showDisclaimer ? (
            <div className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Important:</strong> You can't change this information in the future, and it is important that
                  you put your real credentials.
                </AlertDescription>
              </Alert>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setShowDisclaimer(false)} className="flex-1">
                  Go Back
                </Button>
                <Button
                  onClick={confirmRegistration}
                  disabled={isSubmitting}
                  className="flex-1 bg-black hover:bg-gray-800 text-white"
                >
                  {isSubmitting ? "Creating..." : "Confirm"}
                </Button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {errors.general && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{errors.general}</AlertDescription>
                </Alert>
              )}

              <div>
                <Label htmlFor="userType">I am a *</Label>
                <Select value={userType} onValueChange={(value: "user" | "nonprofit") => setUserType(value)}>
                  <SelectTrigger className={errors.userType ? "border-red-500" : ""}>
                    <SelectValue placeholder="Select account type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Volunteer</SelectItem>
                    <SelectItem value="nonprofit">Volunteer Organization</SelectItem>
                  </SelectContent>
                </Select>
                {errors.userType && <p className="text-red-500 text-sm mt-1">{errors.userType}</p>}
              </div>

              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter your full name"
                  className={errors.name ? "border-red-500" : ""}
                />
                {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
              </div>

              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="Enter your email"
                  className={errors.email ? "border-red-500" : ""}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </div>

              {userType === "user" && (
                <div>
                  <Label htmlFor="age">Age *</Label>
                  <Input
                    id="age"
                    type="number"
                    min="13"
                    max="25"
                    value={formData.age}
                    onChange={(e) => handleInputChange("age", e.target.value)}
                    placeholder="Enter your age"
                    className={errors.age ? "border-red-500" : ""}
                  />
                  {errors.age && <p className="text-red-500 text-sm mt-1">{errors.age}</p>}
                </div>
              )}

              {userType === "nonprofit" && (
                <>
                  <div>
                    <Label htmlFor="organizationName">Organization Name *</Label>
                    <Input
                      id="organizationName"
                      value={formData.organizationName}
                      onChange={(e) => handleInputChange("organizationName", e.target.value)}
                      placeholder="Enter organization name"
                      className={errors.organizationName ? "border-red-500" : ""}
                    />
                    {errors.organizationName && <p className="text-red-500 text-sm mt-1">{errors.organizationName}</p>}
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      placeholder="Enter phone number"
                      className={errors.phone ? "border-red-500" : ""}
                    />
                    {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                  </div>
                </>
              )}

              <Button type="submit" className="w-full bg-black hover:bg-gray-800 text-white">
                Create Account
              </Button>

              <div className="text-center text-sm text-gray-600">
                Already have an account?{" "}
                <Link href="/login" className="text-black hover:underline">
                  Sign in
                </Link>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
