"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Calendar, Clock, MapPin, User, Plus, Mail, Menu, X, Edit, Trash2, UserPlus, UserMinus } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { EditOpportunityModal } from "@/components/edit-opportunity-modal"

export default function NonprofitDashboardPage() {
  const {
    currentUser,
    opportunities,
    getPendingRequestsCount,
    incrementVolunteerCount,
    decrementVolunteerCount,
    deleteOpportunity,
    canEditOpportunity,
    isEventInPast,
    isWithin72Hours,
    loggedHours,
    formatDate,
  } = useAppStore()
  const [showMenu, setShowMenu] = useState(false)
  const [editingOpportunity, setEditingOpportunity] = useState<any>(null)

  if (!currentUser || currentUser.type !== "nonprofit") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only non-profits can access this dashboard.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const pendingCount = getPendingRequestsCount(currentUser.id, currentUser.type)
  const myOpportunities = opportunities.filter((opp) => opp.organizationId === currentUser.id)

  // Separate upcoming and past opportunities
  const upcomingOpportunities = myOpportunities.filter((opp) => !isEventInPast(opp))
  const pastOpportunities = myOpportunities.filter((opp) => isEventInPast(opp))

  const handleIncrementVolunteers = (opportunityId: string) => {
    incrementVolunteerCount(opportunityId)
  }

  const handleDecrementVolunteers = (opportunityId: string) => {
    decrementVolunteerCount(opportunityId)
  }

  const handleDeleteOpportunity = (opportunityId: string) => {
    if (confirm("Are you sure you want to delete this opportunity? This will notify all signed-up students.")) {
      deleteOpportunity(opportunityId)
    }
  }

  const getActualVolunteerCount = (opportunityId: string) => {
    return loggedHours.filter((hour) => hour.opportunityId === opportunityId && hour.status !== "cancelled").length
  }

  const OpportunityCard = ({ opportunity, isPast = false }: { opportunity: any; isPast?: boolean }) => {
    const canEdit = canEditOpportunity(opportunity)
    const within72Hours = isWithin72Hours(opportunity)
    const eventPast = isEventInPast(opportunity)
    const actualVolunteerCount = getActualVolunteerCount(opportunity.id)

    return (
      <Card key={opportunity.id} className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg font-medium">{opportunity.title}</CardTitle>
              <div className="text-gray-600 font-medium">{opportunity.organization}</div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="border-black text-black">
                {opportunity.hours}h
              </Badge>
              {opportunity.maxVolunteers && (
                <Badge variant="secondary" className="border-0">
                  {actualVolunteerCount}/{opportunity.maxVolunteers} volunteers
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div className="flex items-center space-x-2 text-gray-600">
              <MapPin className="h-4 w-4" />
              <span>{opportunity.address}</span>
            </div>

            <div className="flex items-center space-x-2 text-gray-600">
              <Calendar className="h-4 w-4" />
              <span>{formatDate(opportunity.date)}</span>
            </div>

            {opportunity.startTime && opportunity.endTime && (
              <div className="flex items-center space-x-2 text-gray-600">
                <Clock className="h-4 w-4" />
                <span>
                  {opportunity.startTime} - {opportunity.endTime}
                </span>
              </div>
            )}

            {opportunity.minAge && (
              <div className="flex items-center space-x-2 text-gray-600">
                <User className="h-4 w-4" />
                <span>
                  Ages {opportunity.minAge}
                  {opportunity.maxAge ? `-${opportunity.maxAge}` : "+"}
                </span>
              </div>
            )}
          </div>

          <p className="text-sm text-gray-600 line-clamp-2">{opportunity.description}</p>

          {canEdit && (
            <div className="flex justify-between items-center pt-2">
              <div className="flex space-x-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingOpportunity(opportunity)}
                      className="border-gray-300 text-gray-700 hover:bg-gray-50"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Edit Opportunity</p>
                  </TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteOpportunity(opportunity.id)}
                      className="border-red-300 text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Delete Opportunity</p>
                  </TooltipContent>
                </Tooltip>

                {opportunity.maxVolunteers && (
                  <>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleIncrementVolunteers(opportunity.id)}
                          disabled={actualVolunteerCount >= opportunity.maxVolunteers}
                          className="border-green-300 text-green-700 hover:bg-green-50 disabled:opacity-50"
                        >
                          <UserPlus className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>
                          {actualVolunteerCount >= opportunity.maxVolunteers
                            ? "Maximum volunteers reached"
                            : "Add External Volunteer (+1)"}
                        </p>
                      </TooltipContent>
                    </Tooltip>

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDecrementVolunteers(opportunity.id)}
                          disabled={actualVolunteerCount <= 0}
                          className="border-red-300 text-red-700 hover:bg-red-50 disabled:opacity-50"
                        >
                          <UserMinus className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>
                          {actualVolunteerCount <= 0 ? "No volunteers to remove" : "Remove External Volunteer (-1)"}
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </>
                )}
              </div>
            </div>
          )}

          {!canEdit && (
            <div className="text-sm text-gray-500 bg-gray-50 p-2 rounded">
              {eventPast
                ? "Past event - editing disabled"
                : within72Hours
                  ? "Within 72 hours - editing disabled"
                  : "Editing disabled"}
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div>
              <h1 className="text-xl font-light">Dashboard</h1>
              <p className="text-sm text-gray-600">Welcome back, {currentUser.name}</p>
            </div>
            <div className="flex items-center space-x-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/nonprofit/messages">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100 relative">
                      <Mail className="h-4 w-4" />
                      {pendingCount > 0 && (
                        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                          {pendingCount}
                        </span>
                      )}
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Messages</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/nonprofit/settings">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {/* Quick Actions */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Link href="/nonprofit/post" className="flex-1">
              <Button className="w-full bg-black hover:bg-gray-800 text-white">
                <Plus className="h-4 w-4 mr-2" />
                Post Opportunity
              </Button>
            </Link>
            <Link href="/nonprofit/messages">
              <Button
                variant="outline"
                className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
              >
                <Mail className="h-4 w-4 mr-2" />
                Messages
                {pendingCount > 0 && <Badge className="ml-2 bg-red-500 text-white">{pendingCount}</Badge>}
              </Button>
            </Link>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Total Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{myOpportunities.length}</div>
                <p className="text-xs text-gray-500 mt-1">Posted opportunities</p>
              </CardContent>
            </Card>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Upcoming Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{upcomingOpportunities.length}</div>
                <p className="text-xs text-gray-500 mt-1">Future opportunities</p>
              </CardContent>
            </Card>

            <Card className="border-gray-200 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Pending Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{pendingCount}</div>
                <p className="text-xs text-gray-500 mt-1">Hour approval requests</p>
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Opportunities */}
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-medium">Upcoming Opportunities</h2>
                <Link href="/nonprofit/post">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Post New
                  </Button>
                </Link>
              </div>

              {upcomingOpportunities.length === 0 ? (
                <Card className="border-gray-200 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="text-4xl mb-4">📅</div>
                    <h3 className="text-lg font-semibold mb-2">No upcoming opportunities</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      You haven't posted any upcoming volunteer opportunities yet.
                    </p>
                    <Link href="/nonprofit/post">
                      <Button className="bg-black hover:bg-gray-800 text-white">
                        <Plus className="h-4 w-4 mr-2" />
                        Post Opportunity
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {upcomingOpportunities.map((opportunity) => (
                    <OpportunityCard key={opportunity.id} opportunity={opportunity} />
                  ))}
                </div>
              )}
            </div>

            {/* Past Opportunities */}
            {pastOpportunities.length > 0 && (
              <div>
                <h2 className="text-lg font-medium mb-4">Past Opportunities</h2>
                <div className="space-y-4">
                  {pastOpportunities.map((opportunity) => (
                    <OpportunityCard key={opportunity.id} opportunity={opportunity} isPast={true} />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Edit Opportunity Modal */}
        {editingOpportunity && (
          <EditOpportunityModal
            opportunity={editingOpportunity}
            isOpen={!!editingOpportunity}
            onClose={() => setEditingOpportunity(null)}
          />
        )}
      </div>
    </TooltipProvider>
  )
}
