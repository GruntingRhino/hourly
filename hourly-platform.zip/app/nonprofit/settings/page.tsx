"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, AlertCircle, Trash2, User, Mail, Menu, X } from "lucide-react"
import { DeleteAccountModal } from "@/components/delete-account-modal"
import { useAppStore } from "@/lib/store"

export default function NonProfitSettingsPage() {
  const { currentUser, deleteUser, setCurrentUser, getPendingRequestsCount } = useAppStore()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [formData, setFormData] = useState({
    name: currentUser?.name || "",
    organizationName: currentUser?.organizationName || "",
    email: currentUser?.email || "",
  })

  const pendingCount = currentUser ? getPendingRequestsCount(currentUser.id, currentUser.type) : 0

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess("")

    // Simulate API call
    setTimeout(() => {
      setSuccess("Settings saved successfully!")
      setIsLoading(false)
    }, 1000)
  }

  const handleDeleteAccount = () => {
    if (currentUser) {
      deleteUser(currentUser.id)
      setCurrentUser(null)
    }
  }

  if (!currentUser || currentUser.type !== "nonprofit") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only non-profit organizations can access this page.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4">
            <Link href="/nonprofit/dashboard">
              <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-xl font-light">Settings</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Link href="/nonprofit/messages">
              <Button variant="ghost" size="sm" className="hover:bg-gray-100 relative">
                <Mail className="h-4 w-4" />
                {pendingCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {pendingCount}
                  </span>
                )}
              </Button>
            </Link>

            <Button variant="ghost" size="sm" onClick={() => setShowMenu(!showMenu)} className="hover:bg-gray-100">
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {showMenu && (
          <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
            <Link href="/nonprofit/profile">
              <Button variant="ghost" className="w-full justify-start text-sm">
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
            </Link>
            <Link href="/login">
              <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                <X className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </Link>
          </div>
        )}
      </header>

      <div className="p-4">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Account Information */}
          <Card className="border-gray-200 shadow-lg">
            <CardHeader>
              <CardTitle className="font-medium">Account Information</CardTitle>
              <CardDescription>Update your organization details</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSave} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Contact Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="border-gray-300 focus:border-black"
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="organizationName">Organization Name</Label>
                  <Input
                    id="organizationName"
                    value={formData.organizationName}
                    onChange={(e) => setFormData({ ...formData, organizationName: e.target.value })}
                    className="border-gray-300 focus:border-black"
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    className="border-gray-300 focus:border-black bg-gray-50"
                    disabled
                  />
                  <p className="text-xs text-gray-500">Email address cannot be changed</p>
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="border-green-200 bg-green-50">
                    <AlertCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">{success}</AlertDescription>
                  </Alert>
                )}

                <Button type="submit" disabled={isLoading} className="bg-black hover:bg-gray-800 text-white">
                  {isLoading ? "Saving..." : "Save Changes"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Danger Zone */}
          <Card className="border-red-200 shadow-lg">
            <CardHeader>
              <CardTitle className="font-medium text-red-700">Danger Zone</CardTitle>
              <CardDescription>Irreversible and destructive actions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50">
                <div>
                  <h4 className="font-medium text-red-800">Delete Account</h4>
                  <p className="text-sm text-red-600">
                    Permanently delete your account and all associated data. This action cannot be undone.
                  </p>
                </div>
                <Button
                  variant="destructive"
                  onClick={() => setShowDeleteModal(true)}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Delete Account Modal */}
      <DeleteAccountModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleDeleteAccount}
        userType="nonprofit"
      />
    </div>
  )
}
