"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Save, Plus, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { useAppStore } from "@/lib/store"

export default function PostOpportunityPage() {
  const { currentUser, addOpportunity, addMultiDayOpportunities, calculateHoursFromTime } = useAppStore()
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    dates: [""],
    startTime: "",
    endTime: "",
    location: "",
    hours: "",
    customHours: false,
    maxVolunteers: "",
    minAge: "",
    maxAge: "",
    isMultiDay: false,
    requiresSequentialSignup: false,
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!currentUser || currentUser.type !== "nonprofit") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only non-profits can post opportunities.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const calculateAutoHours = () => {
    if (formData.startTime && formData.endTime) {
      return calculateHoursFromTime(formData.startTime, formData.endTime)
    }
    return 0
  }

  const addDate = () => {
    setFormData((prev) => ({
      ...prev,
      dates: [...prev.dates, ""],
    }))
  }

  const removeDate = (index: number) => {
    if (formData.dates.length > 1) {
      setFormData((prev) => ({
        ...prev,
        dates: prev.dates.filter((_, i) => i !== index),
      }))
    }
  }

  const updateDate = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      dates: prev.dates.map((date, i) => (i === index ? value : date)),
    }))
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.title.trim()) {
      newErrors.title = "Title is required"
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required"
    }

    // Validate dates
    const validDates = formData.dates.filter((date) => date.trim())
    if (validDates.length === 0) {
      newErrors.dates = "At least one date is required"
    }

    // Check for duplicate dates
    const uniqueDates = new Set(validDates)
    if (uniqueDates.size !== validDates.length) {
      newErrors.dates = "Duplicate dates are not allowed"
    }

    if (!formData.location.trim()) {
      newErrors.location = "Location is required"
    }

    const autoHours = calculateAutoHours()

    if (formData.customHours) {
      const hours = Number.parseFloat(formData.hours)
      if (!formData.hours || isNaN(hours) || hours <= 0) {
        newErrors.hours = "Valid hours required"
      } else if (autoHours > 0 && hours > autoHours) {
        newErrors.hours = `Hours cannot exceed ${autoHours} (calculated from time range)`
      }
    } else if (autoHours === 0) {
      newErrors.hours = "Please set start and end times, or enable custom hours"
    }

    const maxVolunteers = Number.parseInt(formData.maxVolunteers)
    if (formData.maxVolunteers && (isNaN(maxVolunteers) || maxVolunteers <= 0)) {
      newErrors.maxVolunteers = "Valid number of volunteers required"
    }

    const minAge = Number.parseInt(formData.minAge)
    if (!formData.minAge || isNaN(minAge) || minAge < 13 || minAge > 25) {
      newErrors.minAge = "Minimum age must be between 13 and 25"
    }

    const maxAge = Number.parseInt(formData.maxAge)
    if (formData.maxAge && (isNaN(maxAge) || maxAge < minAge || maxAge > 25)) {
      newErrors.maxAge = "Maximum age must be greater than minimum age and not exceed 25"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)
    try {
      const validDates = formData.dates.filter((date) => date.trim()).sort()
      const finalHours = formData.customHours ? Number.parseFloat(formData.hours) : calculateAutoHours()
      const isMultiDay = validDates.length > 1

      if (isMultiDay) {
        // Create multiple opportunities for multi-day events
        const multiDayGroup = Date.now().toString()
        const opportunities = validDates.map((date, index) => ({
          id: `${Date.now()}-${index}`,
          title: formData.title.trim(),
          description: formData.description.trim(),
          organization: currentUser.organizationName || currentUser.name,
          organizationId: currentUser.id,
          date: date,
          startTime: formData.startTime || undefined,
          endTime: formData.endTime || undefined,
          location: formData.location.trim(),
          hours: finalHours,
          maxVolunteers: formData.maxVolunteers ? Number.parseInt(formData.maxVolunteers) : undefined,
          signedUpCount: 0,
          createdBy: currentUser.id,
          createdAt: new Date().toISOString(),
          minAge: Number.parseInt(formData.minAge),
          maxAge: formData.maxAge ? Number.parseInt(formData.maxAge) : undefined,
          supervisor: currentUser.name,
          supervisorPhone: currentUser.phone,
          supervisorEmail: currentUser.email,
          isMultiDay: true,
          multiDayGroup: multiDayGroup,
          dayNumber: index + 1,
          requiresSequentialSignup: formData.requiresSequentialSignup,
        }))

        addMultiDayOpportunities(opportunities)
      } else {
        // Create single opportunity
        const opportunity = {
          id: Date.now().toString(),
          title: formData.title.trim(),
          description: formData.description.trim(),
          organization: currentUser.organizationName || currentUser.name,
          organizationId: currentUser.id,
          date: validDates[0],
          startTime: formData.startTime || undefined,
          endTime: formData.endTime || undefined,
          location: formData.location.trim(),
          hours: finalHours,
          maxVolunteers: formData.maxVolunteers ? Number.parseInt(formData.maxVolunteers) : undefined,
          signedUpCount: 0,
          createdBy: currentUser.id,
          createdAt: new Date().toISOString(),
          minAge: Number.parseInt(formData.minAge),
          maxAge: formData.maxAge ? Number.parseInt(formData.maxAge) : undefined,
          supervisor: currentUser.name,
          supervisorPhone: currentUser.phone,
          supervisorEmail: currentUser.email,
          isMultiDay: false,
        }

        addOpportunity(opportunity)
      }

      // Reset form
      setFormData({
        title: "",
        description: "",
        dates: [""],
        startTime: "",
        endTime: "",
        location: "",
        hours: "",
        customHours: false,
        maxVolunteers: "",
        minAge: "",
        maxAge: "",
        isMultiDay: false,
        requiresSequentialSignup: false,
      })

      // Redirect to dashboard
      window.location.href = "/nonprofit/dashboard"
    } catch (error) {
      console.error("Failed to post opportunity:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const autoHours = calculateAutoHours()

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center space-x-4 p-4">
          <Link href="/nonprofit/dashboard">
            <Button variant="ghost" size="sm" className="hover:bg-gray-100">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-light">Post Opportunity</h1>
            <p className="text-sm text-gray-600">Create a new volunteer opportunity</p>
          </div>
        </div>
      </header>

      <div className="p-4 max-w-2xl mx-auto">
        <Card className="border-gray-200 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Opportunity Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder="e.g., Community Garden Cleanup"
                  className={errors.title ? "border-red-500" : ""}
                />
                {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
              </div>

              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Describe the volunteer opportunity, what volunteers will do, and any requirements..."
                  rows={4}
                  className={errors.description ? "border-red-500" : ""}
                />
                {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
              </div>

              {/* Dates Section */}
              <div>
                <Label>Dates *</Label>
                <div className="space-y-2">
                  {formData.dates.map((date, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        type="date"
                        value={date}
                        onChange={(e) => updateDate(index, e.target.value)}
                        className={errors.dates ? "border-red-500" : ""}
                      />
                      {formData.dates.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeDate(index)}
                          className="border-red-300 text-red-700 hover:bg-red-50"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addDate}
                    className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Another Date
                  </Button>
                </div>
                {errors.dates && <p className="text-red-500 text-sm mt-1">{errors.dates}</p>}

                {/* Multi-day options */}
                {formData.dates.filter((d) => d.trim()).length > 1 && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="requiresSequentialSignup"
                        checked={formData.requiresSequentialSignup}
                        onCheckedChange={(checked) => handleInputChange("requiresSequentialSignup", checked)}
                      />
                      <Label htmlFor="requiresSequentialSignup" className="text-sm">
                        Require volunteers to sign up for the first day before subsequent days
                      </Label>
                    </div>
                    <p className="text-xs text-blue-600 mt-1">
                      When enabled, volunteers must sign up for day 1 before they can sign up for any other days.
                    </p>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="location">Location *</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => handleInputChange("location", e.target.value)}
                  placeholder="e.g., 123 Main St, New York, NY 10001"
                  className={errors.location ? "border-red-500" : ""}
                />
                {errors.location && <p className="text-red-500 text-sm mt-1">{errors.location}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input
                    id="startTime"
                    type="time"
                    value={formData.startTime}
                    onChange={(e) => handleInputChange("startTime", e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="endTime">End Time</Label>
                  <Input
                    id="endTime"
                    type="time"
                    value={formData.endTime}
                    onChange={(e) => handleInputChange("endTime", e.target.value)}
                  />
                </div>
              </div>

              {/* Hours Section */}
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Checkbox
                    id="customHours"
                    checked={formData.customHours}
                    onCheckedChange={(checked) => handleInputChange("customHours", checked)}
                  />
                  <Label htmlFor="customHours">Set custom hours</Label>
                </div>

                {formData.customHours ? (
                  <div>
                    <Label htmlFor="hours">Hours *</Label>
                    <Input
                      id="hours"
                      type="number"
                      step="0.5"
                      min="0.5"
                      max={autoHours > 0 ? autoHours : undefined}
                      value={formData.hours}
                      onChange={(e) => handleInputChange("hours", e.target.value)}
                      placeholder="e.g., 2.5"
                      className={errors.hours ? "border-red-500" : ""}
                    />
                    {autoHours > 0 && (
                      <p className="text-xs text-gray-500 mt-1">
                        Maximum allowed: {autoHours} hours (based on time range)
                      </p>
                    )}
                    {errors.hours && <p className="text-red-500 text-sm mt-1">{errors.hours}</p>}
                  </div>
                ) : (
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">
                      {autoHours > 0 ? (
                        <>
                          Hours will be automatically calculated: <strong>{autoHours} hours</strong>
                        </>
                      ) : (
                        "Set start and end times to automatically calculate hours"
                      )}
                    </p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="minAge">Minimum Age *</Label>
                  <Input
                    id="minAge"
                    type="number"
                    min="13"
                    max="25"
                    value={formData.minAge}
                    onChange={(e) => handleInputChange("minAge", e.target.value)}
                    placeholder="e.g., 16"
                    className={errors.minAge ? "border-red-500" : ""}
                  />
                  {errors.minAge && <p className="text-red-500 text-sm mt-1">{errors.minAge}</p>}
                </div>

                <div>
                  <Label htmlFor="maxAge">Maximum Age (Optional)</Label>
                  <Input
                    id="maxAge"
                    type="number"
                    min="13"
                    max="25"
                    value={formData.maxAge}
                    onChange={(e) => handleInputChange("maxAge", e.target.value)}
                    placeholder="e.g., 22 (leave blank for no limit)"
                    className={errors.maxAge ? "border-red-500" : ""}
                  />
                  {errors.maxAge && <p className="text-red-500 text-sm mt-1">{errors.maxAge}</p>}
                </div>
              </div>

              <div>
                <Label htmlFor="maxVolunteers">Max Volunteers</Label>
                <Input
                  id="maxVolunteers"
                  type="number"
                  min="1"
                  value={formData.maxVolunteers}
                  onChange={(e) => handleInputChange("maxVolunteers", e.target.value)}
                  placeholder="e.g., 10 (leave blank for unlimited)"
                  className={errors.maxVolunteers ? "border-red-500" : ""}
                />
                {errors.maxVolunteers && <p className="text-red-500 text-sm mt-1">{errors.maxVolunteers}</p>}
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Link href="/nonprofit/dashboard">
                  <Button type="button" variant="outline">
                    Cancel
                  </Button>
                </Link>
                <Button type="submit" disabled={isSubmitting} className="bg-black hover:bg-gray-800 text-white">
                  <Save className="h-4 w-4 mr-2" />
                  {isSubmitting ? "Posting..." : "Post Opportunity"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
