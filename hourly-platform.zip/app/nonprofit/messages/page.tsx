"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ArrowLeft, Calendar, Clock, User, CheckCircle, XCircle, AlertCircle, Mail, Menu, X } from "lucide-react"
import { useAppStore } from "@/lib/store"

export default function NonProfitMessagesPage() {
  const { currentUser, getHourRequestsForNonProfit, approveHourRequest, rejectHourRequest, getPendingRequestsCount } =
    useAppStore()
  const [selectedRequest, setSelectedRequest] = useState<any>(null)
  const [showRejectDialog, setShowRejectDialog] = useState(false)
  const [rejectionReason, setRejectionReason] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [showMenu, setShowMenu] = useState(false)

  const hourRequests = currentUser ? getHourRequestsForNonProfit(currentUser.id) : []
  const pendingCount = currentUser ? getPendingRequestsCount(currentUser.id, currentUser.type) : 0

  const handleApprove = async (requestId: number) => {
    setIsProcessing(true)
    // Simulate API call
    setTimeout(() => {
      approveHourRequest(requestId)
      setIsProcessing(false)
    }, 1000)
  }

  const handleReject = async () => {
    if (!selectedRequest || !rejectionReason.trim()) return

    setIsProcessing(true)
    // Simulate API call
    setTimeout(() => {
      rejectHourRequest(selectedRequest.id, rejectionReason)
      setShowRejectDialog(false)
      setSelectedRequest(null)
      setRejectionReason("")
      setIsProcessing(false)
    }, 1000)
  }

  const openRejectDialog = (request: any) => {
    setSelectedRequest(request)
    setShowRejectDialog(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>
      case "approved":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  if (!currentUser || currentUser.type !== "nonprofit") {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 text-sm mb-4">Only non-profit organizations can access this page.</p>
            <Link href="/login">
              <Button className="bg-black hover:bg-gray-800 text-white">Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/nonprofit/dashboard">
                    <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to Dashboard</p>
                </TooltipContent>
              </Tooltip>
              <h1 className="text-xl font-light">Hour Requests</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowMenu(!showMenu)}
                    className="hover:bg-gray-100"
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Menu</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {showMenu && (
            <div className="absolute right-4 top-16 bg-white rounded-lg shadow-lg border p-2 min-w-[150px]">
              <Link href="/nonprofit/settings">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  <User className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  <X className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </Link>
            </div>
          )}
        </header>

        <div className="p-4">
          {/* Summary */}
          <div className="mb-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-gray-600" />
                <span className="text-lg font-medium">{hourRequests.length} Total Requests</span>
              </div>
              {pendingCount > 0 && <Badge className="bg-yellow-100 text-yellow-800">{pendingCount} Pending</Badge>}
            </div>
          </div>

          {/* Hour Requests */}
          {hourRequests.length === 0 ? (
            <Card className="border-gray-200 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="text-4xl mb-4">📬</div>
                <h3 className="text-lg font-semibold mb-2">No hour requests yet</h3>
                <p className="text-gray-600 text-sm mb-4">
                  When students complete your volunteer opportunities and request hour verification, they'll appear
                  here.
                </p>
                <Link href="/nonprofit/dashboard">
                  <Button className="bg-black hover:bg-gray-800 text-white">Back to Dashboard</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {hourRequests.map((request) => (
                <Card key={request.id} className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg font-medium">{request.opportunityTitle}</CardTitle>
                        <div className="text-gray-600 font-medium">Request from {request.studentName}</div>
                      </div>
                      {getStatusBadge(request.status)}
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <User className="h-4 w-4" />
                        <span>{request.studentEmail}</span>
                      </div>

                      <div className="flex items-center space-x-2 text-gray-600">
                        <Calendar className="h-4 w-4" />
                        <span>Completed: {new Date(request.dateCompleted).toLocaleDateString()}</span>
                      </div>

                      <div className="flex items-center space-x-2 text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>{request.hoursCompleted} hours completed</span>
                      </div>

                      <div className="flex items-center space-x-2 text-gray-600">
                        <Calendar className="h-4 w-4" />
                        <span>Requested: {new Date(request.requestDate).toLocaleDateString()}</span>
                      </div>
                    </div>

                    {request.status === "rejected" && request.rejectionReason && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Rejection reason:</strong> {request.rejectionReason}
                        </AlertDescription>
                      </Alert>
                    )}

                    {request.status === "pending" && (
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openRejectDialog(request)}
                          disabled={isProcessing}
                          className="border-red-300 text-red-700 hover:bg-red-50"
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleApprove(request.id)}
                          disabled={isProcessing}
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Reject Dialog */}
        <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Reject Hour Request</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-gray-700">
                Please provide a reason for rejecting this hour request from {selectedRequest?.studentName}.
              </p>

              <div className="space-y-2">
                <Label htmlFor="rejectionReason">Reason for rejection</Label>
                <Textarea
                  id="rejectionReason"
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Please explain why you're rejecting this request..."
                  rows={3}
                  className="border-gray-300 focus:border-black"
                />
              </div>

              <div className="flex justify-end space-x-4">
                <Button variant="outline" onClick={() => setShowRejectDialog(false)} disabled={isProcessing}>
                  Cancel
                </Button>
                <Button onClick={handleReject} disabled={!rejectionReason.trim() || isProcessing} variant="destructive">
                  {isProcessing ? "Rejecting..." : "Reject Request"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  )
}
