"use client"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AlertTriangle, Calendar, Clock, MapPin } from "lucide-react"

interface OverlapWarningModalProps {
  isOpen: boolean
  onClose: () => void
  onContinue: () => void
  newOpportunity: any
  conflictingEvents: any[]
}

export function OverlapWarningModal({
  isOpen,
  onClose,
  onContinue,
  newOpportunity,
  conflictingEvents,
}: OverlapWarningModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-yellow-600" />
            <span>Time Conflict Detected</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-gray-700">
            The opportunity you're trying to accept conflicts with your existing commitments:
          </p>

          <div className="space-y-3">
            {conflictingEvents.map((event, index) => (
              <div key={index} className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-medium text-yellow-800">{event.title}</h4>
                <div className="text-sm text-yellow-700 space-y-1 mt-1">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-3 w-3" />
                    <span>{new Date(event.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-3 w-3" />
                    <span>
                      {event.startTime} - {event.endTime}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-3 w-3" />
                    <span>{event.location}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <p className="text-sm text-gray-600">Do you want to continue and accept this opportunity anyway?</p>

          <div className="flex justify-end space-x-4">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={onContinue} className="bg-yellow-600 hover:bg-yellow-700 text-white">
              Continue Anyway
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
