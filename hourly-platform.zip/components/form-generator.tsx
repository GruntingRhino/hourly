"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

interface FormField {
  id: string
  type: "text" | "email" | "password" | "number" | "textarea" | "select" | "checkbox"
  label: string
  placeholder?: string
  required?: boolean
  options?: { value: string; label: string }[]
}

interface FormGeneratorProps {
  fields: FormField[]
  onSubmit: (data: Record<string, any>) => void
  submitLabel?: string
  isLoading?: boolean
}

export function FormGenerator({ fields, onSubmit, submitLabel = "Submit", isLoading = false }: FormGeneratorProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const handleChange = (fieldId: string, value: any) => {
    setFormData((prev) => ({ ...prev, [fieldId]: value }))
  }

  const renderField = (field: FormField) => {
    const commonProps = {
      id: field.id,
      required: field.required,
      disabled: isLoading,
    }

    switch (field.type) {
      case "text":
      case "email":
      case "password":
      case "number":
        return (
          <Input
            {...commonProps}
            type={field.type}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleChange(field.id, e.target.value)}
            className="border-gray-300 focus:border-black"
          />
        )

      case "textarea":
        return (
          <Textarea
            {...commonProps}
            placeholder={field.placeholder}
            value={formData[field.id] || ""}
            onChange={(e) => handleChange(field.id, e.target.value)}
            className="border-gray-300 focus:border-black"
          />
        )

      case "select":
        return (
          <Select
            value={formData[field.id] || ""}
            onValueChange={(value) => handleChange(field.id, value)}
            disabled={isLoading}
          >
            <SelectTrigger className="border-gray-300 focus:border-black">
              <SelectValue placeholder={field.placeholder} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )

      case "checkbox":
        return (
          <Checkbox
            {...commonProps}
            checked={formData[field.id] || false}
            onCheckedChange={(checked) => handleChange(field.id, checked)}
          />
        )

      default:
        return null
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {fields.map((field) => (
        <div key={field.id} className="space-y-2">
          <Label htmlFor={field.id}>{field.label}</Label>
          {renderField(field)}
        </div>
      ))}

      <Button type="submit" className="w-full bg-black hover:bg-gray-800 text-white" disabled={isLoading}>
        {isLoading ? "Loading..." : submitLabel}
      </Button>
    </form>
  )
}
