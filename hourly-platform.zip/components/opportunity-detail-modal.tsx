"use client"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, User, Phone, Mail, Users } from "lucide-react"

interface OpportunityDetailModalProps {
  opportunity: any
  isOpen: boolean
  onClose: () => void
}

export function OpportunityDetailModal({ opportunity, isOpen, onClose }: OpportunityDetailModalProps) {
  if (!opportunity) return null

  const getVolunteerStatus = () => {
    if (opportunity.maxVolunteers) {
      const signedUp = opportunity.signedUpCount || 0
      return `${signedUp}/${opportunity.maxVolunteers} volunteers signed up`
    }
    return opportunity.signedUpCount ? `${opportunity.signedUpCount} volunteers signed up` : "0 volunteers signed up"
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-medium">{opportunity.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Organization Info */}
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium text-lg">{opportunity.organization}</h3>
              <p className="text-gray-600">Volunteer Opportunity</p>
              {opportunity.isMultiDay && (
                <p className="text-blue-600 text-sm mt-1">
                  Day {opportunity.dayNumber} of multi-day event
                  {opportunity.requiresSequentialSignup && " (Sequential signup required)"}
                </p>
              )}
            </div>
            <Badge variant="outline" className="border-black text-black">
              {opportunity.hours} hours
            </Badge>
          </div>

          {/* Volunteer Status */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center space-x-2 text-blue-800">
              <Users className="h-5 w-5" />
              <span className="font-medium">{getVolunteerStatus()}</span>
            </div>
          </div>

          {/* Key Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-3">
              <MapPin className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Location</p>
                <p className="text-gray-600">{opportunity.location}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Calendar className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Date</p>
                <p className="text-gray-600">
                  {new Date(opportunity.date + "T00:00:00").toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Time</p>
                <p className="text-gray-600">
                  {opportunity.startTime && opportunity.endTime
                    ? `${opportunity.startTime} - ${opportunity.endTime}`
                    : `${opportunity.hours} hours`}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <User className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Supervisor</p>
                <p className="text-gray-600">{opportunity.supervisor}</p>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="border-t pt-4">
            <h4 className="font-medium mb-3">Contact Information</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-500" />
                <div>
                  <p className="font-medium">Email</p>
                  <p className="text-gray-600">{opportunity.supervisorEmail}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gray-500" />
                <div>
                  <p className="font-medium">Phone</p>
                  <p className="text-gray-600">{opportunity.supervisorPhone}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="border-t pt-4">
            <h4 className="font-medium mb-3">Description</h4>
            <p className="text-gray-700 leading-relaxed">{opportunity.description}</p>
          </div>

          {/* Multi-day Information */}
          {opportunity.isMultiDay && (
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Multi-Day Event</h4>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-blue-800">
                  This is day {opportunity.dayNumber} of a multi-day volunteer opportunity.
                  {opportunity.requiresSequentialSignup && (
                    <span className="block mt-2 font-medium">
                      Note: You must sign up for the first day before you can sign up for subsequent days.
                    </span>
                  )}
                </p>
              </div>
            </div>
          )}

          {/* Cancellation Policy */}
          {opportunity.cancellationDeadlineHours && (
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Cancellation Policy</h4>
              <p className="text-gray-700">
                You can cancel your participation up to {opportunity.cancellationDeadlineHours} hours before the event
                starts.
              </p>
            </div>
          )}

          {/* Close Button */}
          <div className="flex justify-end pt-4 border-t">
            <Button
              onClick={onClose}
              variant="outline"
              className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
