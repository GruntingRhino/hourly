"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"

interface DeleteAccountModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  userType: "student" | "nonprofit"
}

export function DeleteAccountModal({ isOpen, onClose, onConfirm, userType }: DeleteAccountModalProps) {
  const [confirmText, setConfirmText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  const expectedText = "DELETE MY ACCOUNT"
  const isConfirmValid = confirmText === expectedText

  const handleDelete = async () => {
    if (!isConfirmValid) return

    setIsDeleting(true)

    // Simulate API call
    setTimeout(() => {
      onConfirm()
      setIsDeleting(false)
      onClose()
    }, 2000)
  }

  const handleClose = () => {
    setConfirmText("")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <span>Delete Account</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              This action cannot be undone. This will permanently delete your account and remove all your data from our
              servers.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <p className="text-sm text-gray-700">
              {userType === "student"
                ? "All your logged hours, hour requests, and profile information will be permanently deleted."
                : "All your posted opportunities, hour requests, and organization information will be permanently deleted."}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmText">
              Type <strong>{expectedText}</strong> to confirm:
            </Label>
            <Input
              id="confirmText"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder={expectedText}
              className="border-red-300 focus:border-red-500"
            />
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="outline" onClick={handleClose} disabled={isDeleting}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={!isConfirmValid || isDeleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeleting ? "Deleting..." : "Delete Account"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
