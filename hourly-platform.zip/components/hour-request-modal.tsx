"use client"

import { useState } from "react"
import { X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { useAppStore } from "@/lib/store"

interface HourRequestModalProps {
  isOpen: boolean
  onClose: () => void
}

export function HourRequestModal({ isOpen, onClose }: HourRequestModalProps) {
  const { currentUser, getCompletedActivitiesForRequests, submitHourRequest } = useAppStore()
  const [selectedOpportunities, setSelectedOpportunities] = useState<string[]>([])
  const [notes, setNotes] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!isOpen || !currentUser) return null

  const completedActivities = getCompletedActivitiesForRequests()

  const handleToggleOpportunity = (opportunityId: string) => {
    setSelectedOpportunities((prev) =>
      prev.includes(opportunityId) ? prev.filter((id) => id !== opportunityId) : [...prev, opportunityId],
    )
  }

  const handleSubmitRequests = async () => {
    if (selectedOpportunities.length === 0) return

    setIsSubmitting(true)
    try {
      for (const opportunityId of selectedOpportunities) {
        const activity = completedActivities.find((a) => a.id === opportunityId)
        if (activity) {
          await submitHourRequest({
            studentId: currentUser.id,
            studentName: currentUser.name,
            studentEmail: currentUser.email,
            opportunityId: activity.id,
            opportunityTitle: activity.title,
            organizationId: activity.organizationId,
            organizationName: activity.organization,
            hoursCompleted: activity.hours,
            dateCompleted: activity.date,
            nonProfitId: activity.organizationId,
            note: notes,
          })
        }
      }

      setSelectedOpportunities([])
      setNotes("")
      onClose()
    } catch (error) {
      console.error("Failed to submit hour requests:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div>
            <CardTitle className="text-lg font-semibold">Request Hour Approval</CardTitle>
            <p className="text-sm text-gray-600 mt-1">Select completed activities to request hour approval</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent className="overflow-y-auto max-h-[60vh]">
          {completedActivities.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">📋</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Completed Activities</h3>
              <p className="text-gray-600">
                You don't have any completed volunteer activities to request hours for yet.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-3">
                {completedActivities.map((activity) => (
                  <Card
                    key={activity.id}
                    className={`cursor-pointer transition-colors ${
                      selectedOpportunities.includes(activity.id)
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                    onClick={() => handleToggleOpportunity(activity.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{activity.title}</h4>
                          <p className="text-sm text-gray-600">{activity.organization}</p>
                          <p className="text-xs text-gray-500 mt-1">{new Date(activity.date).toLocaleDateString()}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="border-green-500 text-green-700">
                            {activity.hours}h
                          </Badge>
                          <div
                            className={`w-4 h-4 rounded border-2 ${
                              selectedOpportunities.includes(activity.id)
                                ? "bg-blue-500 border-blue-500"
                                : "border-gray-300"
                            }`}
                          >
                            {selectedOpportunities.includes(activity.id) && (
                              <div className="w-full h-full flex items-center justify-center">
                                <div className="w-2 h-2 bg-white rounded-full" />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="space-y-2">
                <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                  Additional Notes (Optional)
                </label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any additional details about your volunteer work..."
                  rows={3}
                  className="w-full"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmitRequests}
                  disabled={selectedOpportunities.length === 0 || isSubmitting}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {isSubmitting
                    ? "Submitting..."
                    : `Submit ${selectedOpportunities.length} Request${selectedOpportunities.length !== 1 ? "s" : ""}`}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
