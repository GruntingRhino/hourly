"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, User, Eye } from "lucide-react"
import { useAppStore } from "@/lib/store"

interface OpportunityCardProps {
  opportunity: any
  onViewDetails?: () => void
  onSignUp?: () => void
  onSkip?: () => void
  onReject?: () => void
  showActions?: boolean
}

export function OpportunityCard({
  opportunity,
  onViewDetails,
  onSignUp,
  onSkip,
  onReject,
  showActions = true,
}: OpportunityCardProps) {
  const { formatDate } = useAppStore()

  return (
    <Card className="border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-medium">{opportunity.title}</CardTitle>
            <div className="text-gray-600 font-medium">{opportunity.organization}</div>
            {opportunity.isMultiDay && (
              <div className="text-sm text-blue-600 mt-1">Day {opportunity.dayNumber} of multi-day event</div>
            )}
          </div>
          <Badge variant="outline" className="border-black text-black">
            {opportunity.hours}h
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin className="h-4 w-4" />
            <span>{opportunity.location}</span>
          </div>

          <div className="flex items-center space-x-2 text-gray-600">
            <Calendar className="h-4 w-4" />
            <span>{formatDate(opportunity.date)}</span>
          </div>

          <div className="flex items-center space-x-2 text-gray-600">
            <User className="h-4 w-4" />
            <span>{opportunity.supervisor}</span>
          </div>

          <div className="flex items-center space-x-2 text-gray-600">
            <Clock className="h-4 w-4" />
            <span>
              {opportunity.startTime && opportunity.endTime
                ? `${opportunity.startTime} - ${opportunity.endTime}`
                : `${opportunity.hours} hours`}
            </span>
          </div>
        </div>

        <div className="text-sm text-gray-700 line-clamp-3">{opportunity.description}</div>

        {showActions && (
          <div className="flex justify-between items-center pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onViewDetails}
              className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
            >
              <Eye className="h-4 w-4 mr-2" />
              Details
            </Button>

            <div className="flex space-x-2">
              {onSkip && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onSkip}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  Skip
                </Button>
              )}
              {onReject && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onReject}
                  className="border-red-300 text-red-700 hover:bg-red-50 bg-transparent"
                >
                  Not Interested
                </Button>
              )}
              {onSignUp && (
                <Button size="sm" onClick={onSignUp} className="bg-black hover:bg-gray-800 text-white">
                  Sign Up
                </Button>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
