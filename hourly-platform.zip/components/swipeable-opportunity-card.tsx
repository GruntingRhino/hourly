"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, User, Users } from "lucide-react"

interface SwipeableOpportunityCardProps {
  opportunity: any
  onSwipe: (direction: "left" | "right" | "down") => void
  showSwipeHints?: boolean
}

export function SwipeableOpportunityCard({
  opportunity,
  onSwipe,
  showSwipeHints = true,
}: SwipeableOpportunityCardProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [startPos, setStartPos] = useState({ x: 0, y: 0 })
  const cardRef = useRef<HTMLDivElement>(null)

  const handleStart = (clientX: number, clientY: number) => {
    setIsDragging(true)
    setStartPos({ x: clientX, y: clientY })
  }

  const handleMove = (clientX: number, clientY: number) => {
    if (!isDragging) return

    const deltaX = clientX - startPos.x
    const deltaY = clientY - startPos.y
    setDragOffset({ x: deltaX, y: deltaY })
  }

  const handleEnd = () => {
    if (!isDragging) return

    const threshold = 100
    const { x, y } = dragOffset

    if (Math.abs(x) > threshold) {
      onSwipe(x > 0 ? "right" : "left")
    } else if (y > threshold) {
      onSwipe("down")
    }

    setIsDragging(false)
    setDragOffset({ x: 0, y: 0 })
  }

  // Mouse events
  const handleMouseDown = (e: React.MouseEvent) => {
    handleStart(e.clientX, e.clientY)
  }

  // Touch events
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0]
    handleStart(touch.clientX, touch.clientY)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0]
    handleMove(touch.clientX, touch.clientY)
  }

  const handleTouchEnd = () => {
    handleEnd()
  }

  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        handleMove(e.clientX, e.clientY)
      }
    }

    const handleGlobalMouseUp = () => {
      if (isDragging) {
        handleEnd()
      }
    }

    if (isDragging) {
      document.addEventListener("mousemove", handleGlobalMouseMove)
      document.addEventListener("mouseup", handleGlobalMouseUp)
    }

    return () => {
      document.removeEventListener("mousemove", handleGlobalMouseMove)
      document.removeEventListener("mouseup", handleGlobalMouseUp)
    }
  }, [isDragging, dragOffset])

  const cardStyle = {
    transform: `translate(${dragOffset.x}px, ${dragOffset.y}px) rotate(${dragOffset.x * 0.05}deg)`,
    transition: isDragging ? "none" : "transform 0.3s ease-out",
    opacity: Math.abs(dragOffset.x) > 50 || dragOffset.y > 50 ? 0.8 : 1,
  }

  const getSwipeIndicator = () => {
    if (Math.abs(dragOffset.x) > 50) {
      return dragOffset.x > 0 ? "ACCEPT" : "NOT INTERESTED"
    }
    if (dragOffset.y > 50) {
      return "SKIP"
    }
    return null
  }

  const indicator = getSwipeIndicator()

  const getVolunteerStatus = () => {
    if (opportunity.maxVolunteers) {
      const signedUp = opportunity.signedUpCount || 0
      return `${signedUp}/${opportunity.maxVolunteers} volunteers signed up`
    }
    return opportunity.signedUpCount ? `${opportunity.signedUpCount} volunteers signed up` : null
  }

  return (
    <div className="relative">
      <Card
        ref={cardRef}
        className="w-full max-w-sm mx-auto cursor-grab active:cursor-grabbing select-none relative border-gray-200 shadow-lg"
        style={cardStyle}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {indicator && (
          <div
            className={`absolute inset-0 flex items-center justify-center z-10 rounded-lg ${
              indicator === "ACCEPT"
                ? "bg-green-500/20"
                : indicator === "NOT INTERESTED"
                  ? "bg-red-500/20"
                  : "bg-yellow-500/20"
            }`}
          >
            <div
              className={`text-xl font-bold px-4 py-2 rounded-lg ${
                indicator === "ACCEPT"
                  ? "bg-green-500 text-white"
                  : indicator === "NOT INTERESTED"
                    ? "bg-red-500 text-white"
                    : "bg-yellow-500 text-white"
              }`}
            >
              {indicator}
            </div>
          </div>
        )}

        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-medium pr-4">{opportunity.title}</CardTitle>
            <Badge variant="outline" className="border-black text-black">
              {opportunity.hours}h
            </Badge>
          </div>
          <div className="text-gray-600 font-medium">{opportunity.organization}</div>
        </CardHeader>

        <CardContent className="space-y-4">
          <p className="text-gray-700 text-sm leading-relaxed line-clamp-3">{opportunity.description}</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div className="flex items-center space-x-2 text-gray-600">
              <MapPin className="h-4 w-4" />
              <span>{opportunity.location}</span>
            </div>

            <div className="flex items-center space-x-2 text-gray-600">
              <Calendar className="h-4 w-4" />
              <span>{new Date(opportunity.date).toLocaleDateString()}</span>
            </div>

            <div className="flex items-center space-x-2 text-gray-600">
              <User className="h-4 w-4" />
              <span>{opportunity.supervisor}</span>
            </div>

            <div className="flex items-center space-x-2 text-gray-600">
              <Clock className="h-4 w-4" />
              <span>
                {opportunity.startTime && opportunity.endTime
                  ? `${opportunity.startTime} - ${opportunity.endTime}`
                  : `${opportunity.hours} hours`}
              </span>
            </div>
          </div>

          {getVolunteerStatus() && (
            <div className="flex items-center space-x-2 text-sm text-blue-600 bg-blue-50 p-2 rounded">
              <Users className="h-4 w-4" />
              <span>{getVolunteerStatus()}</span>
            </div>
          )}

          {showSwipeHints && (
            <div className="text-center text-xs text-gray-500 pt-2 border-t">
              <p>Swipe right to accept • Swipe down to skip • Swipe left to reject</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
