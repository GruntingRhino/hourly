"use client"

import { useState } from "react"
import { X, AlertCircle, Edit, Trash2, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAppStore } from "@/lib/store"

interface NotificationCenterProps {
  isOpen: boolean
  onClose: () => void
}

export function NotificationCenter({ isOpen, onClose }: NotificationCenterProps) {
  const { currentUser, getNotificationsForStudent, markNotificationAsRead, cancelOpportunitySignup } = useAppStore()
  const [processingCancel, setProcessingCancel] = useState<string | null>(null)

  if (!isOpen || !currentUser) return null

  const notifications = getNotificationsForStudent(currentUser.id)
  const unreadCount = notifications.filter((n) => !n.read).length

  const handleMarkAsRead = (notificationId: string) => {
    markNotificationAsRead(notificationId)
  }

  const handleCancelSignup = async (opportunityId: string, notificationId: string) => {
    setProcessingCancel(opportunityId)
    try {
      cancelOpportunitySignup(currentUser.id, opportunityId)
      markNotificationAsRead(notificationId)
    } catch (error) {
      console.error("Failed to cancel signup:", error)
    } finally {
      setProcessingCancel(null)
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "opportunity_edited":
        return <Edit className="h-4 w-4 text-blue-500" />
      case "opportunity_deleted":
        return <Trash2 className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div>
            <CardTitle className="text-lg font-semibold">Notifications</CardTitle>
            {unreadCount > 0 && <p className="text-sm text-gray-600 mt-1">{unreadCount} unread notifications</p>}
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent className="overflow-y-auto max-h-[60vh]">
          {notifications.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">All caught up!</h3>
              <p className="text-gray-600">You have no notifications at this time.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {notifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`border ${notification.read ? "border-gray-200" : "border-blue-200 bg-blue-50"}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-sm font-medium text-gray-900">{notification.title}</h4>
                          {!notification.read && (
                            <Badge variant="secondary" className="text-xs">
                              New
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{notification.message}</p>

                        {notification.changes && notification.changes.length > 0 && (
                          <div className="bg-gray-50 rounded-md p-3 mb-3">
                            <h5 className="text-xs font-medium text-gray-700 mb-2">Changes made:</h5>
                            <ul className="text-xs text-gray-600 space-y-1">
                              {notification.changes.map((change, index) => (
                                <li key={index} className="flex justify-between">
                                  <span className="font-medium">{change.field}:</span>
                                  <span>
                                    {change.oldValue} → {change.newValue}
                                  </span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        <div className="flex items-center justify-between">
                          <p className="text-xs text-gray-500">
                            {new Date(notification.createdAt).toLocaleDateString()} at{" "}
                            {new Date(notification.createdAt).toLocaleTimeString()}
                          </p>
                          <div className="flex space-x-2">
                            {!notification.read && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleMarkAsRead(notification.id)}
                                className="text-xs"
                              >
                                Mark as Read
                              </Button>
                            )}
                            {notification.type === "opportunity_edited" && notification.opportunityId && (
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleCancelSignup(notification.opportunityId!, notification.id)}
                                disabled={processingCancel === notification.opportunityId}
                                className="text-xs"
                              >
                                {processingCancel === notification.opportunityId ? "Canceling..." : "Cancel Signup"}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
