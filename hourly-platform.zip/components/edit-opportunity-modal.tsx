"use client"

import type React from "react"

import { useState } from "react"
import { X, Save, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAppStore } from "@/lib/store"
import type { Opportunity } from "@/lib/store"

interface EditOpportunityModalProps {
  opportunity: Opportunity
  isOpen: boolean
  onClose: () => void
}

export function EditOpportunityModal({ opportunity, isOpen, onClose }: EditOpportunityModalProps) {
  const { updateOpportunity, deleteOpportunity, canEditOpportunity, isWithin72Hours } = useAppStore()
  const canEdit = canEditOpportunity(opportunity)
  const within72Hours = isWithin72Hours(opportunity)
  const [formData, setFormData] = useState({
    title: opportunity.title,
    description: opportunity.description,
    date: opportunity.date,
    startTime: opportunity.startTime || "",
    endTime: opportunity.endTime || "",
    location: opportunity.location,
    hours: opportunity.hours.toString(),
    maxVolunteers: opportunity.maxVolunteers?.toString() || "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  if (!isOpen) return null

  // Don't allow editing if not editable
  if (!canEdit) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-lg font-semibold">Cannot Edit Event</CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              {within72Hours
                ? "This opportunity is within 72 hours of its start time and cannot be edited."
                : "This opportunity has already passed and cannot be edited or deleted."}
            </p>
            <div className="flex justify-end">
              <Button onClick={onClose}>Close</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.title.trim()) {
      newErrors.title = "Title is required"
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required"
    }

    if (!formData.date) {
      newErrors.date = "Date is required"
    }

    if (!formData.location.trim()) {
      newErrors.location = "Location is required"
    }

    const hours = Number.parseFloat(formData.hours)
    if (!formData.hours || isNaN(hours) || hours <= 0) {
      newErrors.hours = "Valid hours required"
    }

    // Validate hours don't exceed time duration
    if (formData.startTime && formData.endTime && formData.hours) {
      const start = new Date(`2000-01-01T${formData.startTime}`)
      const end = new Date(`2000-01-01T${formData.endTime}`)
      const durationHours = (end.getTime() - start.getTime()) / (1000 * 60 * 60)

      if (hours > durationHours) {
        newErrors.hours = `Hours cannot exceed ${durationHours} (time between start and end)`
      }
    }

    const maxVolunteers = Number.parseInt(formData.maxVolunteers)
    if (formData.maxVolunteers && (isNaN(maxVolunteers) || maxVolunteers <= 0)) {
      newErrors.maxVolunteers = "Valid number of volunteers required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)
    try {
      const updatedOpportunity: Opportunity = {
        ...opportunity,
        title: formData.title.trim(),
        description: formData.description.trim(),
        date: formData.date,
        startTime: formData.startTime || undefined,
        endTime: formData.endTime || undefined,
        location: formData.location.trim(),
        hours: Number.parseFloat(formData.hours),
        maxVolunteers: formData.maxVolunteers ? Number.parseInt(formData.maxVolunteers) : undefined,
      }

      updateOpportunity(opportunity.id, updatedOpportunity)
      onClose()
    } catch (error) {
      console.error("Failed to update opportunity:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = () => {
    deleteOpportunity(opportunity.id)
    onClose()
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-lg font-semibold">Edit Opportunity</CardTitle>
          <div className="flex space-x-2">
            <Button variant="destructive" size="sm" onClick={() => setShowDeleteConfirm(true)} className="text-xs">
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="overflow-y-auto max-h-[70vh]">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                className={errors.title ? "border-red-500" : ""}
              />
              {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                rows={3}
                className={errors.description ? "border-red-500" : ""}
              />
              {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="date">Date *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange("date", e.target.value)}
                  className={errors.date ? "border-red-500" : ""}
                />
                {errors.date && <p className="text-red-500 text-sm mt-1">{errors.date}</p>}
              </div>

              <div>
                <Label htmlFor="location">Location *</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => handleInputChange("location", e.target.value)}
                  className={errors.location ? "border-red-500" : ""}
                />
                {errors.location && <p className="text-red-500 text-sm mt-1">{errors.location}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="startTime">Start Time</Label>
                <Input
                  id="startTime"
                  type="time"
                  value={formData.startTime}
                  onChange={(e) => handleInputChange("startTime", e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="endTime">End Time</Label>
                <Input
                  id="endTime"
                  type="time"
                  value={formData.endTime}
                  onChange={(e) => handleInputChange("endTime", e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="hours">Hours *</Label>
                <Input
                  id="hours"
                  type="number"
                  step="0.5"
                  min="0.5"
                  value={formData.hours}
                  onChange={(e) => handleInputChange("hours", e.target.value)}
                  className={errors.hours ? "border-red-500" : ""}
                />
                {errors.hours && <p className="text-red-500 text-sm mt-1">{errors.hours}</p>}
              </div>
            </div>

            <div>
              <Label htmlFor="maxVolunteers">Max Volunteers</Label>
              <Input
                id="maxVolunteers"
                type="number"
                min="1"
                value={formData.maxVolunteers}
                onChange={(e) => handleInputChange("maxVolunteers", e.target.value)}
                className={errors.maxVolunteers ? "border-red-500" : ""}
              />
              {errors.maxVolunteers && <p className="text-red-500 text-sm mt-1">{errors.maxVolunteers}</p>}
            </div>

            <div className="flex justify-end space-x-2 pt-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting} className="bg-black hover:bg-gray-800 text-white">
                <Save className="h-4 w-4 mr-2" />
                {isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-75 z-60 flex items-center justify-center p-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-red-600">Delete Opportunity</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Are you sure you want to delete this opportunity? This action cannot be undone and will notify all
                signed-up students.
              </p>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowDeleteConfirm(false)}>
                  Cancel
                </Button>
                <Button variant="destructive" onClick={handleDelete}>
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
