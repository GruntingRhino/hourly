import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface User {
  id: string
  name: string
  email: string
  type: "user" | "nonprofit"
  organizationName?: string
  age?: number
  phone?: string
  createdAt: string
}

export interface Opportunity {
  id: string
  title: string
  description: string
  organization: string
  organizationId: string
  date: string
  startTime?: string
  endTime?: string
  location: string
  hours: number
  maxVolunteers?: number
  signedUpCount?: number
  supervisor?: string
  supervisorPhone?: string
  supervisorEmail?: string
  createdBy?: string
  createdAt: string
  minAge?: number
  maxAge?: number
  isMultiDay?: boolean
  multiDayGroup?: string
  dayNumber?: number
  requiresSequentialSignup?: boolean
}

export interface LoggedHour {
  id: string
  studentId: string
  studentName: string
  organizationId: string
  organization: string
  opportunityId: string
  title: string
  date: string
  startTime?: string
  endTime?: string
  hours: number
  location: string
  supervisor: string
  status: "accepted" | "completed" | "cancelled"
  hasRequest?: boolean
  dateLogged: string
}

export interface HourRequest {
  id: string
  studentId: string
  studentName: string
  studentEmail: string
  opportunityId: string
  opportunityTitle: string
  organizationId: string
  organizationName: string
  hoursCompleted: number
  dateCompleted: string
  requestDate: string
  status: "pending" | "approved" | "rejected" | "cancelled"
  rejectionReason?: string
  nonProfitId: string
  note?: string
}

export interface ReviewedOpportunity {
  id: string
  studentId: string
  opportunityId: string
  reviewAction: "accepted" | "skipped" | "rejected"
  reviewDate: string
}

export interface Notification {
  id: string
  studentId: string
  type: "opportunity_edited" | "opportunity_deleted" | "account_deleted" | "hours_approved" | "hours_rejected"
  title: string
  message: string
  opportunityId?: string
  opportunityTitle: string
  changes?: Array<{
    field: string
    oldValue: string
    newValue: string
  }>
  read: boolean
  createdAt: string
}

interface AppState {
  currentUser: User | null
  users: User[]
  opportunities: Opportunity[]
  loggedHours: LoggedHour[]
  hourRequests: HourRequest[]
  reviewedOpportunities: ReviewedOpportunity[]
  notifications: Notification[]
  nextId: number
  nextUserId: number
  nextRequestId: number
  nextNotificationId: number

  // User management
  setCurrentUser: (user: User | null) => void
  addUser: (user: Omit<User, "id" | "createdAt">) => boolean
  deleteUser: (userId: string) => void
  getUserByEmail: (email: string) => User | undefined

  // Opportunity management
  addOpportunity: (opportunity: Opportunity) => void
  addMultiDayOpportunities: (opportunities: Opportunity[]) => void
  updateOpportunity: (id: string, updates: Partial<Opportunity>) => void
  deleteOpportunity: (id: string) => void
  incrementVolunteerCount: (opportunityId: string) => void
  getAvailableOpportunities: (userId?: string) => Opportunity[]
  getOpportunitiesForNonProfit: (nonProfitId: string) => Opportunity[]
  decrementVolunteerCount: (opportunityId: string) => void
  cleanupOrphanedOpportunities: () => void
  canSignUpForOpportunity: (userId: string, opportunity: Opportunity) => boolean

  // Hour tracking actions
  addLoggedHour: (hour: Omit<LoggedHour, "id" | "dateLogged">) => void
  updateLoggedHourStatus: (id: string, status: LoggedHour["status"]) => void
  getActiveLoggedHours: () => LoggedHour[]
  getCancelledLoggedHours: () => LoggedHour[]
  getTotalSignedUpHours: () => number
  getTotalCompletedHours: () => number
  getCompletedActivitiesCount: () => number
  cancelLoggedHour: (hourId: string) => void
  markHourAsCompleted: (hourId: string) => void
  getCompletedActivitiesForRequests: () => LoggedHour[]
  getCompletedHours: () => LoggedHour[]

  // Hour request actions
  submitHourRequest: (request: Omit<HourRequest, "id" | "requestDate" | "status">) => void
  getHourRequestsForStudent: (studentId: string) => HourRequest[]
  getHourRequestsForNonProfit: (nonProfitId: string) => HourRequest[]
  getCancelledHourRequests: (userId: string) => HourRequest[]
  approveHourRequest: (requestId: string) => void
  rejectHourRequest: (requestId: string, reason: string) => void
  cancelHourRequest: (requestId: string) => void
  getPendingRequestsCount: (userId: string, userType: "student" | "nonprofit") => number

  // Review actions
  markAsReviewed: (opportunityId: string, action: "accepted" | "skipped" | "rejected") => void
  getReviewedOpportunities: () => ReviewedOpportunity[]

  // Notification actions
  getNotificationsForStudent: (studentId: string) => Notification[]
  markNotificationAsRead: (notificationId: string) => void
  createNotification: (notification: Omit<Notification, "id" | "createdAt">) => void

  // Utility functions
  hasTimeConflict: (newOpportunity: Opportunity, existingHours: LoggedHour[]) => LoggedHour[]
  isEventInPast: (opportunity: Opportunity | LoggedHour) => boolean
  isWithin72Hours: (opportunity: Opportunity) => boolean
  canEditOpportunity: (opportunity: Opportunity) => boolean
  formatDate: (dateString: string) => string
  parseDate: (dateString: string) => Date
  calculateHoursFromTime: (startTime: string, endTime: string) => number
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: [],
      opportunities: [],
      loggedHours: [],
      hourRequests: [],
      reviewedOpportunities: [],
      notifications: [],
      nextId: 3,
      nextUserId: 1,
      nextRequestId: 1,
      nextNotificationId: 1,

      // User management
      setCurrentUser: (user) => set({ currentUser: user }),

      addUser: (userData) => {
        const state = get()
        const existingUser = state.users.find((u) => u.email === userData.email)
        if (existingUser) return false

        const newUser: User = {
          ...userData,
          id: state.nextUserId.toString(),
          createdAt: new Date().toISOString(),
        }

        set({
          users: [...state.users, newUser],
          nextUserId: state.nextUserId + 1,
        })
        return true
      },

      deleteUser: (userId) => {
        set((state) => {
          const user = state.users.find((u) => u.id === userId)
          if (!user) return state

          let updatedState = { ...state }

          // If deleting a nonprofit, cascade delete their opportunities
          if (user.type === "nonprofit") {
            const nonProfitOpportunities = state.opportunities.filter((opp) => opp.organizationId === userId)

            // Create notifications for affected students
            const affectedStudents = new Set<string>()
            nonProfitOpportunities.forEach((opp) => {
              state.loggedHours
                .filter((hour) => hour.opportunityId === opp.id && hour.status !== "cancelled")
                .forEach((hour) => affectedStudents.add(hour.studentId))
            })

            const newNotifications = Array.from(affectedStudents).map((studentId) => ({
              id: state.nextNotificationId.toString(),
              studentId,
              type: "account_deleted" as const,
              title: "Opportunity Removed",
              message: "This opportunity was removed because the account that created it no longer exists.",
              opportunityTitle: "Removed opportunity",
              read: false,
              createdAt: new Date().toISOString(),
            }))

            updatedState = {
              ...updatedState,
              opportunities: state.opportunities.filter((opp) => opp.organizationId !== userId),
              loggedHours: state.loggedHours.map((hour) =>
                nonProfitOpportunities.some((opp) => opp.id === hour.opportunityId)
                  ? { ...hour, status: "cancelled" as const }
                  : hour,
              ),
              notifications: [...state.notifications, ...newNotifications],
              nextNotificationId: state.nextNotificationId + newNotifications.length,
            }
          }

          return {
            ...updatedState,
            users: state.users.filter((u) => u.id !== userId),
            currentUser: state.currentUser?.id === userId ? null : state.currentUser,
          }
        })
      },

      getUserByEmail: (email) => {
        return get().users.find((u) => u.email === email)
      },

      // Opportunity management
      addOpportunity: (opportunity) => {
        set((state) => ({
          opportunities: [...state.opportunities, opportunity],
        }))
      },

      addMultiDayOpportunities: (opportunities) => {
        set((state) => ({
          opportunities: [...state.opportunities, ...opportunities],
        }))
      },

      updateOpportunity: (id, updates) => {
        set((state) => {
          const opportunity = state.opportunities.find((o) => o.id === id)
          if (!opportunity) return state

          const updatedOpportunity = { ...opportunity, ...updates }

          // Track changes for notifications
          const changes: Array<{ field: string; oldValue: string; newValue: string }> = []

          if (opportunity.title !== updatedOpportunity.title) {
            changes.push({ field: "Title", oldValue: opportunity.title, newValue: updatedOpportunity.title })
          }
          if (opportunity.date !== updatedOpportunity.date) {
            changes.push({ field: "Date", oldValue: opportunity.date, newValue: updatedOpportunity.date })
          }
          if (opportunity.startTime !== updatedOpportunity.startTime) {
            changes.push({
              field: "Start Time",
              oldValue: opportunity.startTime || "Not set",
              newValue: updatedOpportunity.startTime || "Not set",
            })
          }
          if (opportunity.location !== updatedOpportunity.location) {
            changes.push({ field: "Location", oldValue: opportunity.location, newValue: updatedOpportunity.location })
          }

          // Create notifications for affected students
          if (changes.length > 0) {
            const affectedStudents = state.loggedHours
              .filter((hour) => hour.opportunityId === id && hour.status !== "cancelled")
              .map((hour) => hour.studentId)

            const newNotifications = affectedStudents.map((studentId) => ({
              id: state.nextNotificationId.toString(),
              studentId,
              type: "opportunity_edited" as const,
              title: "Opportunity Updated",
              message: `The opportunity "${opportunity.title}" has been updated.`,
              opportunityId: id,
              opportunityTitle: opportunity.title,
              changes,
              read: false,
              createdAt: new Date().toISOString(),
            }))

            return {
              opportunities: state.opportunities.map((o) => (o.id === id ? updatedOpportunity : o)),
              notifications: [...state.notifications, ...newNotifications],
              nextNotificationId: state.nextNotificationId + newNotifications.length,
            }
          }

          return {
            opportunities: state.opportunities.map((o) => (o.id === id ? updatedOpportunity : o)),
          }
        })
      },

      deleteOpportunity: (id) => {
        set((state) => {
          const opportunity = state.opportunities.find((o) => o.id === id)
          if (!opportunity) return state

          // If it's a multi-day opportunity, delete all related opportunities
          let opportunitiesToDelete = [opportunity]
          if (opportunity.isMultiDay && opportunity.multiDayGroup) {
            opportunitiesToDelete = state.opportunities.filter((opp) => opp.multiDayGroup === opportunity.multiDayGroup)
          }

          // Create notifications for affected students
          const affectedStudents = new Set<string>()
          opportunitiesToDelete.forEach((opp) => {
            state.loggedHours
              .filter((hour) => hour.opportunityId === opp.id && hour.status !== "cancelled")
              .forEach((hour) => affectedStudents.add(hour.studentId))
          })

          const newNotifications = Array.from(affectedStudents).map((studentId) => ({
            id: state.nextNotificationId.toString(),
            studentId,
            type: "opportunity_deleted" as const,
            title: "Opportunity Cancelled",
            message: `The opportunity "${opportunity.title}" has been cancelled.`,
            opportunityId: id,
            opportunityTitle: opportunity.title,
            read: false,
            createdAt: new Date().toISOString(),
          }))

          const deletedIds = opportunitiesToDelete.map((opp) => opp.id)

          return {
            opportunities: state.opportunities.filter((o) => !deletedIds.includes(o.id)),
            loggedHours: state.loggedHours.map((hour) =>
              deletedIds.includes(hour.opportunityId) ? { ...hour, status: "cancelled" as const } : hour,
            ),
            notifications: [...state.notifications, ...newNotifications],
            nextNotificationId: state.nextNotificationId + newNotifications.length,
          }
        })
      },

      incrementVolunteerCount: (opportunityId) => {
        set((state) => {
          const opportunity = state.opportunities.find((opp) => opp.id === opportunityId)
          if (!opportunity) return state

          // Check if we would exceed the maximum
          const currentCount = opportunity.signedUpCount || 0
          if (opportunity.maxVolunteers && currentCount >= opportunity.maxVolunteers) {
            return state // Don't increment if at max
          }

          return {
            opportunities: state.opportunities.map((opp) =>
              opp.id === opportunityId ? { ...opp, signedUpCount: currentCount + 1 } : opp,
            ),
          }
        })
      },

      canSignUpForOpportunity: (userId, opportunity) => {
        const state = get()

        // If it's not a multi-day opportunity or doesn't require sequential signup, allow signup
        if (!opportunity.isMultiDay || !opportunity.requiresSequentialSignup || !opportunity.multiDayGroup) {
          return true
        }

        // For multi-day opportunities with sequential signup requirement
        const multiDayOpportunities = state.opportunities
          .filter((opp) => opp.multiDayGroup === opportunity.multiDayGroup)
          .sort((a, b) => (a.dayNumber || 0) - (b.dayNumber || 0))

        // Check if user has signed up for the first day
        const firstDay = multiDayOpportunities[0]
        if (!firstDay) return true

        const hasSignedUpForFirstDay = state.loggedHours.some(
          (hour) => hour.studentId === userId && hour.opportunityId === firstDay.id && hour.status !== "cancelled",
        )

        // If trying to sign up for the first day, always allow
        if (opportunity.id === firstDay.id) {
          return true
        }

        // For subsequent days, only allow if signed up for first day
        return hasSignedUpForFirstDay
      },

      getAvailableOpportunities: (userId) => {
        const state = get()
        if (!userId) return state.opportunities

        const user = state.users.find((u) => u.id === userId)
        if (!user || !user.age) return []

        // Get opportunities the user has already signed up for
        const signedUpOpportunityIds = state.loggedHours
          .filter((hour) => hour.studentId === userId && hour.status !== "cancelled")
          .map((hour) => hour.opportunityId)

        // Get opportunities the user has already reviewed
        const reviewedOpportunityIds = state.reviewedOpportunities
          .filter((rev) => rev.studentId === userId)
          .map((rev) => rev.opportunityId)

        return state.opportunities.filter((opp) => {
          // Hide if already signed up
          if (signedUpOpportunityIds.includes(opp.id)) return false

          // Hide if already reviewed
          if (reviewedOpportunityIds.includes(opp.id)) return false

          // Hide if opportunity is full
          const actualSignupCount = state.loggedHours.filter(
            (hour) => hour.opportunityId === opp.id && hour.status !== "cancelled",
          ).length
          if (opp.maxVolunteers && actualSignupCount >= opp.maxVolunteers) return false

          // Check age requirements
          if (opp.minAge && user.age < opp.minAge) return false
          if (opp.maxAge && user.age > opp.maxAge) return false

          // Check if user can sign up for this opportunity (sequential signup rule)
          if (!get().canSignUpForOpportunity(userId, opp)) return false

          // Only show future opportunities
          return !get().isEventInPast(opp)
        })
      },

      getOpportunitiesForNonProfit: (nonProfitId) => {
        return get().opportunities.filter((opp) => opp.organizationId === nonProfitId)
      },

      decrementVolunteerCount: (opportunityId) => {
        set((state) => ({
          opportunities: state.opportunities.map((opp) =>
            opp.id === opportunityId ? { ...opp, signedUpCount: Math.max(0, (opp.signedUpCount || 0) - 1) } : opp,
          ),
        }))
      },

      cleanupOrphanedOpportunities: () => {
        set((state) => {
          const validUserIds = state.users.map((u) => u.id)
          const orphanedOpportunities = state.opportunities.filter(
            (opp) => opp.organizationId && !validUserIds.includes(opp.organizationId),
          )

          if (orphanedOpportunities.length === 0) return state

          // Create notifications for affected students
          const affectedStudents = new Set<string>()
          orphanedOpportunities.forEach((opp) => {
            state.loggedHours
              .filter((hour) => hour.opportunityId === opp.id && hour.status !== "cancelled")
              .forEach((hour) => affectedStudents.add(hour.studentId))
          })

          const newNotifications = Array.from(affectedStudents).map((studentId) => ({
            id: state.nextNotificationId.toString(),
            studentId,
            type: "account_deleted" as const,
            title: "Opportunity Removed",
            message: "This opportunity was removed because the account that created it no longer exists.",
            opportunityTitle: "Removed opportunity",
            read: false,
            createdAt: new Date().toISOString(),
          }))

          return {
            opportunities: state.opportunities.filter(
              (opp) => !opp.organizationId || validUserIds.includes(opp.organizationId),
            ),
            loggedHours: state.loggedHours.map((hour) =>
              orphanedOpportunities.some((opp) => opp.id === hour.opportunityId)
                ? { ...hour, status: "cancelled" as const }
                : hour,
            ),
            notifications: [...state.notifications, ...newNotifications],
            nextNotificationId: state.nextNotificationId + newNotifications.length,
          }
        })
      },

      // Hour tracking actions
      addLoggedHour: (hourData) => {
        const state = get()

        // Check if student is already signed up for this opportunity
        const existingSignup = state.loggedHours.find(
          (hour) =>
            hour.studentId === hourData.studentId &&
            hour.opportunityId === hourData.opportunityId &&
            hour.status !== "cancelled",
        )

        if (existingSignup) {
          console.warn("Student already signed up for this opportunity")
          return // Don't add duplicate
        }

        const newHour: LoggedHour = {
          ...hourData,
          id: state.nextId.toString(),
          dateLogged: new Date().toISOString(),
        }

        set({
          loggedHours: [...state.loggedHours, newHour],
          nextId: state.nextId + 1,
        })
      },

      updateLoggedHourStatus: (id, status) => {
        set((state) => ({
          loggedHours: state.loggedHours.map((h) => (h.id === id ? { ...h, status } : h)),
        }))
      },

      getActiveLoggedHours: () => {
        const state = get()
        const currentUserId = state.currentUser?.id
        if (!currentUserId) return []

        return state.loggedHours.filter((hour) => hour.studentId === currentUserId && hour.status !== "cancelled")
      },

      getCancelledLoggedHours: () => {
        const state = get()
        const currentUserId = state.currentUser?.id
        if (!currentUserId) return []

        return state.loggedHours.filter((hour) => hour.studentId === currentUserId && hour.status === "cancelled")
      },

      getTotalSignedUpHours: () => {
        const activeHours = get().getActiveLoggedHours()
        return activeHours.reduce((sum, hour) => sum + hour.hours, 0)
      },

      getTotalCompletedHours: () => {
        const activeHours = get().getActiveLoggedHours()
        return activeHours.filter((hour) => hour.status === "completed").reduce((sum, hour) => sum + hour.hours, 0)
      },

      getCompletedActivitiesCount: () => {
        const activeHours = get().getActiveLoggedHours()
        return activeHours.filter((hour) => hour.status === "completed").length
      },

      cancelLoggedHour: (hourId) => {
        set((state) => ({
          loggedHours: state.loggedHours.map((hour) =>
            hour.id === hourId ? { ...hour, status: "cancelled" as const } : hour,
          ),
        }))
      },

      markHourAsCompleted: (hourId) => {
        set((state) => ({
          loggedHours: state.loggedHours.map((hour) =>
            hour.id === hourId ? { ...hour, status: "completed" as const } : hour,
          ),
        }))
      },

      getCompletedActivitiesForRequests: () => {
        const state = get()
        const currentUserId = state.currentUser?.id
        if (!currentUserId) return []

        return state.loggedHours.filter(
          (hour) =>
            hour.studentId === currentUserId &&
            hour.status === "accepted" &&
            get().isEventInPast(hour) &&
            !hour.hasRequest,
        )
      },

      getCompletedHours: () => {
        const state = get()
        const currentUserId = state.currentUser?.id
        if (!currentUserId) return []

        return state.loggedHours.filter((hour) => hour.studentId === currentUserId && hour.status === "completed")
      },

      // Hour request actions
      submitHourRequest: (requestData) => {
        const state = get()
        const newRequest: HourRequest = {
          ...requestData,
          id: state.nextRequestId.toString(),
          requestDate: new Date().toISOString(),
          status: "pending",
        }

        set({
          hourRequests: [...state.hourRequests, newRequest],
          nextRequestId: state.nextRequestId + 1,
        })

        // Mark the logged hour as having a pending request
        set((state) => ({
          loggedHours: state.loggedHours.map((hour) =>
            hour.opportunityId === requestData.opportunityId && hour.studentId === requestData.studentId
              ? { ...hour, hasRequest: true }
              : hour,
          ),
        }))
      },

      getHourRequestsForStudent: (studentId) => {
        return get().hourRequests.filter((req) => req.studentId === studentId && req.status !== "cancelled")
      },

      getHourRequestsForNonProfit: (nonProfitId) => {
        return get().hourRequests.filter((req) => req.nonProfitId === nonProfitId && req.status !== "cancelled")
      },

      getCancelledHourRequests: (userId) => {
        return get().hourRequests.filter((req) => req.studentId === userId && req.status === "cancelled")
      },

      approveHourRequest: (requestId) => {
        const state = get()
        const request = state.hourRequests.find((req) => req.id === requestId)

        if (request) {
          set((state) => ({
            hourRequests: state.hourRequests.map((req) =>
              req.id === requestId ? { ...req, status: "approved" as const } : req,
            ),
          }))

          // Mark the corresponding logged hour as completed
          get().markHourAsCompleted(request.opportunityId)

          // Create notification for student
          const notification = {
            studentId: request.studentId,
            type: "hours_approved" as const,
            title: "Hours Approved",
            message: `Your ${request.hoursCompleted} hours for "${request.opportunityTitle}" have been approved.`,
            opportunityId: request.opportunityId,
            opportunityTitle: request.opportunityTitle,
            read: false,
          }
          get().createNotification(notification)
        }
      },

      rejectHourRequest: (requestId, reason) => {
        const state = get()
        const request = state.hourRequests.find((req) => req.id === requestId)

        set((state) => ({
          hourRequests: state.hourRequests.map((req) =>
            req.id === requestId ? { ...req, status: "rejected" as const, rejectionReason: reason } : req,
          ),
        }))

        // Create notification for student
        if (request) {
          const notification = {
            studentId: request.studentId,
            type: "hours_rejected" as const,
            title: "Hours Rejected",
            message: `Your hours request for "${request.opportunityTitle}" was rejected. Reason: ${reason}`,
            opportunityId: request.opportunityId,
            opportunityTitle: request.opportunityTitle,
            read: false,
          }
          get().createNotification(notification)
        }
      },

      cancelHourRequest: (requestId) => {
        set((state) => ({
          hourRequests: state.hourRequests.map((req) =>
            req.id === requestId ? { ...req, status: "cancelled" as const } : req,
          ),
        }))
      },

      getPendingRequestsCount: (userId, userType) => {
        const state = get()
        if (userType === "student") {
          return 0 // Students don't have pending requests in messages anymore
        } else {
          return state.hourRequests.filter((req) => req.nonProfitId === userId && req.status === "pending").length
        }
      },

      // Review actions
      markAsReviewed: (opportunityId, action) => {
        const state = get()
        const currentUserId = state.currentUser?.id
        if (!currentUserId) return

        const opportunity = state.opportunities.find((opp) => opp.id === opportunityId)
        if (!opportunity) return

        // Remove existing review if it exists
        const existingReview = state.reviewedOpportunities.find(
          (rev) => rev.studentId === currentUserId && rev.opportunityId === opportunityId,
        )

        if (existingReview) {
          set((state) => ({
            reviewedOpportunities: state.reviewedOpportunities.filter(
              (rev) => !(rev.studentId === currentUserId && rev.opportunityId === opportunityId),
            ),
          }))
        }

        if (action === "accepted") {
          // Check if already signed up to prevent duplicates
          const existingSignup = state.loggedHours.find(
            (hour) =>
              hour.studentId === currentUserId && hour.opportunityId === opportunityId && hour.status !== "cancelled",
          )

          if (existingSignup) {
            console.warn("Student already signed up for this opportunity")
            return
          }

          // Add to logged hours
          const newLoggedHour: Omit<LoggedHour, "id" | "dateLogged"> = {
            studentId: currentUserId,
            studentName: state.currentUser?.name || "",
            organizationId: opportunity.organizationId,
            organization: opportunity.organization,
            opportunityId: opportunity.id,
            title: opportunity.title,
            date: opportunity.date,
            startTime: opportunity.startTime,
            endTime: opportunity.endTime,
            hours: opportunity.hours,
            location: opportunity.location,
            supervisor: opportunity.supervisor || "TBD",
            status: "accepted",
          }
          get().addLoggedHour(newLoggedHour)
        } else {
          // Add to reviewed opportunities
          const reviewedOpportunity: ReviewedOpportunity = {
            id: state.nextId.toString(),
            studentId: currentUserId,
            opportunityId,
            reviewAction: action,
            reviewDate: new Date().toISOString(),
          }

          set((state) => ({
            reviewedOpportunities: [...state.reviewedOpportunities, reviewedOpportunity],
            nextId: state.nextId + 1,
          }))
        }
      },

      getReviewedOpportunities: () => {
        const state = get()
        const currentUserId = state.currentUser?.id
        if (!currentUserId) return []

        const reviewedIds = state.reviewedOpportunities
          .filter((rev) => rev.studentId === currentUserId)
          .map((rev) => rev.opportunityId)

        return state.opportunities
          .filter((opp) => reviewedIds.includes(opp.id))
          .map((opp) => {
            const review = state.reviewedOpportunities.find(
              (rev) => rev.studentId === currentUserId && rev.opportunityId === opp.id,
            )
            return {
              ...opp,
              reviewAction: review?.reviewAction || "skipped",
              reviewDate: review?.reviewDate || new Date().toISOString(),
            }
          })
      },

      // Notification actions
      getNotificationsForStudent: (studentId) => {
        return get()
          .notifications.filter((notification) => notification.studentId === studentId)
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      },

      markNotificationAsRead: (notificationId) => {
        set((state) => ({
          notifications: state.notifications.map((notification) =>
            notification.id === notificationId ? { ...notification, read: true } : notification,
          ),
        }))
      },

      createNotification: (notificationData) => {
        const state = get()
        const newNotification: Notification = {
          ...notificationData,
          id: state.nextNotificationId.toString(),
          createdAt: new Date().toISOString(),
        }

        set({
          notifications: [...state.notifications, newNotification],
          nextNotificationId: state.nextNotificationId + 1,
        })
      },

      // Utility functions
      hasTimeConflict: (newOpportunity, existingHours) => {
        if (!newOpportunity.startTime || !newOpportunity.endTime) return []

        const newStart = new Date(`${newOpportunity.date}T${newOpportunity.startTime}`)
        const newEnd = new Date(`${newOpportunity.date}T${newOpportunity.endTime}`)

        return existingHours.filter((hour) => {
          if (hour.status === "cancelled" || !hour.startTime || !hour.endTime) return false

          const existingStart = new Date(`${hour.date}T${hour.startTime}`)
          const existingEnd = new Date(`${hour.date}T${hour.endTime}`)

          return (
            (newStart >= existingStart && newStart < existingEnd) ||
            (newEnd > existingStart && newEnd <= existingEnd) ||
            (newStart <= existingStart && newEnd >= existingEnd)
          )
        })
      },

      isEventInPast: (opportunity) => {
        const now = new Date()
        const eventDate = get().parseDate(opportunity.date)

        // If the event has a start time, use it for precise comparison
        if (opportunity.startTime) {
          const [hours, minutes] = opportunity.startTime.split(":").map(Number)
          eventDate.setHours(hours, minutes, 0, 0)
          return eventDate < now
        }

        // If no start time, consider it past at the end of the day
        eventDate.setHours(23, 59, 59, 999)
        return eventDate < now
      },

      isWithin72Hours: (opportunity) => {
        const now = new Date()
        if (!opportunity.startTime) return false

        const eventDate = get().parseDate(opportunity.date)
        const [hours, minutes] = opportunity.startTime.split(":").map(Number)
        eventDate.setHours(hours, minutes, 0, 0)

        const timeDiff = eventDate.getTime() - now.getTime()
        const hoursDiff = timeDiff / (1000 * 60 * 60)
        return hoursDiff <= 72 && hoursDiff > 0
      },

      canEditOpportunity: (opportunity) => {
        const isInPast = get().isEventInPast(opportunity)
        const isClose = get().isWithin72Hours(opportunity)
        return !isInPast && !isClose
      },

      formatDate: (dateString) => {
        const date = get().parseDate(dateString)
        return date.toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      },

      parseDate: (dateString) => {
        // Handle YYYY-MM-DD format properly to avoid timezone issues
        if (dateString.includes("-")) {
          const [year, month, day] = dateString.split("-").map(Number)
          return new Date(year, month - 1, day)
        } else {
          // MM/DD/YYYY format
          return new Date(dateString)
        }
      },

      calculateHoursFromTime: (startTime, endTime) => {
        if (!startTime || !endTime) return 0

        const start = new Date(`2000-01-01T${startTime}`)
        const end = new Date(`2000-01-01T${endTime}`)

        const diffMs = end.getTime() - start.getTime()
        const diffHours = diffMs / (1000 * 60 * 60)

        return Math.max(0, Math.round(diffHours * 2) / 2) // Round to nearest 0.5
      },
    }),
    {
      name: "hourly-app-storage",
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.cleanupOrphanedOpportunities()
        }
      },
    },
  ),
)
